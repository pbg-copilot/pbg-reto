--
-- PostgreSQL database dump
--

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA analytics;


--
-- Name: autofix; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA autofix;


--
-- Name: aws_validation; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA aws_validation;


--
-- Name: gifts; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA gifts;


--
-- Name: help; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA help;


--
-- Name: marketplace; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA marketplace;


--
-- Name: onboarding; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA onboarding;


--
-- Name: support; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA support;


--
-- Name: teamops; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA teamops;


--
-- Name: viewer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA viewer;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: call_coaching_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.call_coaching_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'call_coaching is append only'; RETURN NEW; END $$;


--
-- Name: call_coaching_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.call_coaching_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'call_coaching is append only'; RETURN NEW; END $$;


--
-- Name: call_transcripts_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.call_transcripts_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'call_transcripts is append only'; RETURN NEW; END $$;


--
-- Name: call_transcripts_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.call_transcripts_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'call_transcripts is append only'; RETURN NEW; END $$;


--
-- Name: compliance_detections_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.compliance_detections_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'compliance_detections is append only'; RETURN NEW; END $$;


--
-- Name: compliance_detections_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.compliance_detections_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'compliance_detections is append only'; RETURN NEW; END $$;


--
-- Name: evidence_audit_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.evidence_audit_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'evidence_audit_log is append only'; RETURN NEW; END $$;


--
-- Name: evidence_audit_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.evidence_audit_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'evidence_audit_log is append only'; RETURN NEW; END $$;


--
-- Name: script_master_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.script_master_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'script_master is append only'; RETURN NEW; END $$;


--
-- Name: script_master_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.script_master_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'script_master is append only'; RETURN NEW; END $$;


--
-- Name: signature_resets_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.signature_resets_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'agent_signature_resets is append only'; RETURN NEW; END $$;


--
-- Name: signature_resets_no_update_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.signature_resets_no_update_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'agent_signature_resets is append only'; RETURN NEW; END $$;


--
-- Name: usage_events_facts_immutable_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.usage_events_facts_immutable_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF OLD.id <> NEW.id
  OR OLD.account_id <> NEW.account_id
  OR OLD.kind <> NEW.kind
  OR OLD.quantity <> NEW.quantity
  OR OLD.unit <> NEW.unit
  OR OLD.occurred_at <> NEW.occurred_at
  OR OLD.source <> NEW.source
  OR OLD.idempotency_key <> NEW.idempotency_key THEN RAISE EXCEPTION 'usage_events is append only: event facts cannot be rewritten'; END IF; RETURN NEW; END $$;


--
-- Name: usage_events_no_delete_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.usage_events_no_delete_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'usage_events is append only'; RETURN NEW; END $$;


--
-- Name: usage_events_no_void_after_report_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.usage_events_no_void_after_report_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF NEW.voided_at IS NOT NULL AND OLD.reported_to_stripe_at IS NOT NULL THEN RAISE EXCEPTION 'usage_events: already reported to Stripe, void it there with a credit note'; END IF; RETURN NEW; END $$;


--
-- Name: usage_events_report_stamp_once_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.usage_events_report_stamp_once_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF OLD.reported_to_stripe_at IS NOT NULL
 AND (NEW.reported_to_stripe_at IS NULL OR NEW.reported_to_stripe_at <> OLD.reported_to_stripe_at) THEN RAISE EXCEPTION 'usage_events.reported_to_stripe_at is write once: already reported'; END IF; RETURN NEW; END $$;


--
-- Name: usage_events_void_once_fn(); Type: FUNCTION; Schema: onboarding; Owner: -
--

CREATE FUNCTION onboarding.usage_events_void_once_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF OLD.voided_at IS NOT NULL
 AND (NEW.voided_at IS NULL OR NEW.voided_at <> OLD.voided_at) THEN RAISE EXCEPTION 'usage_events.voided_at is write once: this event is already voided'; END IF; RETURN NEW; END $$;


--
-- Name: datetime(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.datetime(value text) RETURNS text
    LANGUAGE sql STABLE
    AS $$ SELECT to_char(CASE WHEN value='now' THEN CURRENT_TIMESTAMP ELSE value::timestamptz END AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS') $$;


--
-- Name: hex(bytea); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.hex(value bytea) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$ SELECT upper(encode(value,'hex')) $$;


--
-- Name: randomblob(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.randomblob(n integer) RETURNS bytea
    LANGUAGE sql
    AS $$ SELECT public.gen_random_bytes(n) $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.agents (
    account_id text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    full_name text DEFAULT ''::text NOT NULL,
    npn text DEFAULT ''::text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    status text DEFAULT ''::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    subscription_status text DEFAULT ''::text NOT NULL,
    billing_mode text DEFAULT ''::text NOT NULL,
    current_period_end bigint,
    cancel_at_period_end bigint DEFAULT 0 NOT NULL,
    agency_key text DEFAULT ''::text NOT NULL,
    agency_name text DEFAULT ''::text NOT NULL,
    language text DEFAULT ''::text NOT NULL,
    onboarding_completed bigint DEFAULT 0 NOT NULL,
    verification_status text DEFAULT ''::text NOT NULL,
    account_created_at bigint DEFAULT 0 NOT NULL,
    sessions_total bigint DEFAULT 0 NOT NULL,
    sessions_30d bigint DEFAULT 0 NOT NULL,
    last_session_at bigint,
    coached_calls bigint DEFAULT 0 NOT NULL,
    numbers_count bigint DEFAULT 0 NOT NULL,
    numbers text DEFAULT ''::text NOT NULL,
    states text DEFAULT ''::text NOT NULL,
    last_activity_at bigint,
    last_activity_kind text DEFAULT ''::text NOT NULL,
    collected_at bigint NOT NULL,
    agent_tz text DEFAULT 'America/New_York'::text NOT NULL,
    agent_tz_source text DEFAULT 'default'::text NOT NULL,
    agent_tz_approx bigint DEFAULT 1 NOT NULL
);


--
-- Name: calls; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.calls (
    attempt_id text NOT NULL,
    direction text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    npn text DEFAULT ''::text NOT NULL,
    agent_name text DEFAULT ''::text NOT NULL,
    agency_key text DEFAULT ''::text NOT NULL,
    agency_name text DEFAULT ''::text NOT NULL,
    client_number text DEFAULT ''::text NOT NULL,
    from_number text DEFAULT ''::text NOT NULL,
    language text DEFAULT ''::text NOT NULL,
    call_mode text DEFAULT ''::text NOT NULL,
    session_id text DEFAULT ''::text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    started_at text NOT NULL,
    started_epoch bigint NOT NULL,
    agent_answered_at text DEFAULT ''::text NOT NULL,
    client_answered_at text DEFAULT ''::text NOT NULL,
    bridged_at text DEFAULT ''::text NOT NULL,
    ended_at text DEFAULT ''::text NOT NULL,
    answered bigint DEFAULT 0 NOT NULL,
    bridged bigint DEFAULT 0 NOT NULL,
    no_answer_reason text DEFAULT ''::text NOT NULL,
    hangup_cause text DEFAULT ''::text NOT NULL,
    hangup_source text DEFAULT ''::text NOT NULL,
    sip_hangup_cause text DEFAULT ''::text NOT NULL,
    talk_seconds real DEFAULT 0 NOT NULL,
    agent_leg_seconds real DEFAULT 0 NOT NULL,
    conversation bigint DEFAULT 0 NOT NULL,
    disclosure_qualifies bigint DEFAULT 0 NOT NULL,
    disclosure_matched bigint DEFAULT 0 NOT NULL,
    disclosure_gap_secs real,
    disclosure_language text DEFAULT ''::text NOT NULL,
    disposition text DEFAULT ''::text NOT NULL,
    callback_at text DEFAULT ''::text NOT NULL,
    quotes_count bigint DEFAULT 0 NOT NULL,
    forward_attempted bigint DEFAULT 0 NOT NULL,
    forwarded bigint DEFAULT 0 NOT NULL,
    forward_fail_reason text DEFAULT ''::text NOT NULL,
    day_et text NOT NULL,
    hour_et bigint NOT NULL,
    minute_of_day_et bigint NOT NULL,
    dow_et bigint NOT NULL,
    collected_at bigint NOT NULL,
    ring_seconds real DEFAULT 0 NOT NULL,
    agent_tz text DEFAULT 'America/New_York'::text NOT NULL,
    agent_tz_source text DEFAULT 'default'::text NOT NULL,
    day_local text DEFAULT ''::text NOT NULL,
    hour_local bigint DEFAULT 0 NOT NULL,
    minute_of_day_local bigint DEFAULT 0 NOT NULL,
    dow_local bigint DEFAULT 0 NOT NULL
);


--
-- Name: collector_runs; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.collector_runs (
    run_id text NOT NULL,
    started_at text NOT NULL,
    finished_at text DEFAULT ''::text NOT NULL,
    finished_epoch bigint DEFAULT 0 NOT NULL,
    ok bigint DEFAULT 0 NOT NULL,
    journal_since text DEFAULT ''::text NOT NULL,
    journal_lines bigint DEFAULT 0 NOT NULL,
    attempts_written bigint DEFAULT 0 NOT NULL,
    quotes_written bigint DEFAULT 0 NOT NULL,
    agents_written bigint DEFAULT 0 NOT NULL,
    days_rolled bigint DEFAULT 0 NOT NULL,
    duration_ms bigint DEFAULT 0 NOT NULL,
    error text DEFAULT ''::text NOT NULL
);


--
-- Name: day_rollup; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.day_rollup (
    day_et text NOT NULL,
    scope text NOT NULL,
    scope_key text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    clients_reached bigint DEFAULT 0 NOT NULL,
    answered bigint DEFAULT 0 NOT NULL,
    conversations bigint DEFAULT 0 NOT NULL,
    talk_seconds_total real DEFAULT 0 NOT NULL,
    quotes bigint DEFAULT 0 NOT NULL,
    callbacks bigint DEFAULT 0 NOT NULL,
    callbacks_forwarded bigint DEFAULT 0 NOT NULL,
    disclosure_qualifying bigint DEFAULT 0 NOT NULL,
    disclosure_matched bigint DEFAULT 0 NOT NULL,
    collected_at bigint NOT NULL
);


--
-- Name: quotes; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.quotes (
    quote_id text NOT NULL,
    session_id text DEFAULT ''::text NOT NULL,
    attempt_id text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    agency_key text DEFAULT ''::text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    carrier text DEFAULT ''::text NOT NULL,
    product text DEFAULT ''::text NOT NULL,
    face_amount_cents bigint DEFAULT 0 NOT NULL,
    monthly_premium_cents bigint DEFAULT 0 NOT NULL,
    annual_premium_cents bigint DEFAULT 0 NOT NULL,
    derived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    created_epoch bigint NOT NULL,
    day_et text NOT NULL,
    hour_et bigint NOT NULL,
    minute_of_day_et bigint NOT NULL,
    collected_at bigint NOT NULL
);


--
-- Name: revenue_accounts; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.revenue_accounts (
    account_id text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    full_name text DEFAULT ''::text NOT NULL,
    agency_name text DEFAULT ''::text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    bucket text DEFAULT ''::text NOT NULL,
    bucket_marker text DEFAULT ''::text NOT NULL,
    counts_toward_mrr bigint DEFAULT 0 NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    plan_label text DEFAULT ''::text NOT NULL,
    billing_mode text DEFAULT ''::text NOT NULL,
    account_status text DEFAULT ''::text NOT NULL,
    subscription_status text DEFAULT ''::text NOT NULL,
    monthly_cents bigint,
    amount_source text DEFAULT ''::text NOT NULL,
    amount_evidence text DEFAULT ''::text NOT NULL,
    billing_interval text DEFAULT ''::text NOT NULL,
    stripe_customer_id text DEFAULT ''::text NOT NULL,
    stripe_subscription_id text DEFAULT ''::text NOT NULL,
    stripe_status text DEFAULT ''::text NOT NULL,
    stripe_price_id text DEFAULT ''::text NOT NULL,
    membership_start text DEFAULT ''::text NOT NULL,
    membership_start_source text DEFAULT ''::text NOT NULL,
    membership_start_epoch bigint DEFAULT 0 NOT NULL,
    period_end_epoch bigint,
    period_end_is_placeholder bigint DEFAULT 0 NOT NULL,
    cancel_at_period_end bigint DEFAULT 0 NOT NULL,
    prepaid_months bigint,
    next_anchor text DEFAULT ''::text NOT NULL,
    transferred_from text DEFAULT ''::text NOT NULL,
    manual_note text DEFAULT ''::text NOT NULL,
    account_created_epoch bigint DEFAULT 0 NOT NULL,
    collected_at bigint NOT NULL,
    bucket_marker_kind text DEFAULT ''::text NOT NULL,
    bucket_marker_detail text DEFAULT ''::text NOT NULL
);


--
-- Name: revenue_meta; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.revenue_meta (
    id text NOT NULL,
    collected_at bigint NOT NULL,
    stripe_read bigint DEFAULT 0 NOT NULL,
    stripe_subscriptions bigint DEFAULT 0 NOT NULL,
    stripe_error text DEFAULT ''::text NOT NULL,
    accounts_total bigint DEFAULT 0 NOT NULL
);


--
-- Name: watermark; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.watermark (
    id text NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    updated_at bigint DEFAULT 0 NOT NULL
);


--
-- Name: acts; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.acts (
    id bigint NOT NULL,
    at bigint NOT NULL,
    report_id text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    class_id text DEFAULT ''::text NOT NULL,
    outcome text NOT NULL,
    line_es text DEFAULT ''::text NOT NULL,
    posted text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL
);


--
-- Name: acts_id_seq; Type: SEQUENCE; Schema: autofix; Owner: -
--

ALTER TABLE autofix.acts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME autofix.acts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: costs; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.costs (
    id bigint NOT NULL,
    at bigint NOT NULL,
    thread_key text DEFAULT ''::text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    usd real DEFAULT 0 NOT NULL
);


--
-- Name: costs_id_seq; Type: SEQUENCE; Schema: autofix; Owner: -
--

ALTER TABLE autofix.costs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME autofix.costs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filed_words; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.filed_words (
    hash text NOT NULL,
    issue_id text DEFAULT ''::text NOT NULL,
    at bigint NOT NULL
);


--
-- Name: heard; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.heard (
    hash text NOT NULL,
    user_id text NOT NULL,
    at bigint NOT NULL,
    outcome text DEFAULT ''::text NOT NULL
);


--
-- Name: held; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.held (
    key text NOT NULL,
    user_id text DEFAULT ''::text NOT NULL,
    speaker text DEFAULT ''::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    at bigint NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL
);


--
-- Name: processed; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.processed (
    report_id text NOT NULL,
    outcome text NOT NULL,
    at bigint NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.settings (
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: threads; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.threads (
    key text NOT NULL,
    user_id text NOT NULL,
    started_at bigint NOT NULL,
    last_at bigint NOT NULL
);


--
-- Name: turns; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.turns (
    id bigint NOT NULL,
    thread_key text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    at bigint NOT NULL
);


--
-- Name: turns_id_seq; Type: SEQUENCE; Schema: autofix; Owner: -
--

ALTER TABLE autofix.turns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME autofix.turns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: words; Type: TABLE; Schema: autofix; Owner: -
--

CREATE TABLE autofix.words (
    code text NOT NULL,
    report_id text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    class_id text NOT NULL,
    proposal text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    word text DEFAULT ''::text NOT NULL,
    word_from text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    decided_at bigint,
    expires_at bigint NOT NULL
);


--
-- Name: script_master_before_cleanup_20261015; Type: TABLE; Schema: aws_validation; Owner: -
--

CREATE TABLE aws_validation.script_master_before_cleanup_20261015 (
    id text NOT NULL,
    brand text NOT NULL,
    language text NOT NULL,
    version bigint NOT NULL,
    effective_date text NOT NULL,
    content_encrypted text NOT NULL,
    created_at bigint NOT NULL,
    variant text DEFAULT 'master'::text NOT NULL
);


--
-- Name: care_automation_rules; Type: TABLE; Schema: gifts; Owner: -
--

CREATE TABLE gifts.care_automation_rules (
    id text NOT NULL,
    agent_account_id text NOT NULL,
    occasion text NOT NULL,
    enabled bigint DEFAULT 0 NOT NULL,
    strategy_json text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    client_scope text DEFAULT 'all'::text NOT NULL,
    client_name text DEFAULT ''::text NOT NULL
);


--
-- Name: care_billing_profiles; Type: TABLE; Schema: gifts; Owner: -
--

CREATE TABLE gifts.care_billing_profiles (
    agent_account_id text NOT NULL,
    stripe_customer_id text NOT NULL,
    customer_source text DEFAULT 'care'::text NOT NULL,
    stripe_mode text DEFAULT 'test'::text NOT NULL,
    default_payment_method text,
    card_brand text,
    card_last4 text,
    card_exp_month bigint,
    card_exp_year bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: care_events; Type: TABLE; Schema: gifts; Owner: -
--

CREATE TABLE gifts.care_events (
    id bigint NOT NULL,
    order_id text NOT NULL,
    type text NOT NULL,
    actor text DEFAULT 'system'::text NOT NULL,
    data text,
    created_at text NOT NULL
);


--
-- Name: care_events_id_seq; Type: SEQUENCE; Schema: gifts; Owner: -
--

ALTER TABLE gifts.care_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME gifts.care_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: care_opportunities; Type: TABLE; Schema: gifts; Owner: -
--

CREATE TABLE gifts.care_opportunities (
    id text NOT NULL,
    agent_account_id text NOT NULL,
    client_name text DEFAULT ''::text NOT NULL,
    lead_id text,
    occasion text,
    suggested_combo_id text,
    reason text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    due_date text,
    status text DEFAULT 'open'::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: care_orders; Type: TABLE; Schema: gifts; Owner: -
--

CREATE TABLE gifts.care_orders (
    id text NOT NULL,
    dedup_key text NOT NULL,
    agent_account_id text NOT NULL,
    agent_name text DEFAULT ''::text NOT NULL,
    agent_agency text DEFAULT ''::text NOT NULL,
    verified bigint DEFAULT 0 NOT NULL,
    source text DEFAULT 'care'::text NOT NULL,
    occasion text NOT NULL,
    client_name text NOT NULL,
    client_language text DEFAULT 'en'::text NOT NULL,
    lead_id text,
    policy_id text,
    coverage_amount_usd bigint,
    catalog_version bigint NOT NULL,
    combo_id text NOT NULL,
    tier bigint NOT NULL,
    price_cents bigint NOT NULL,
    mail_class text DEFAULT 'parcel'::text NOT NULL,
    combo_status text DEFAULT 'live'::text NOT NULL,
    name_en text NOT NULL,
    name_es text NOT NULL,
    contents_en text NOT NULL,
    contents_es text NOT NULL,
    personal_message text DEFAULT ''::text NOT NULL,
    message_language text DEFAULT 'en'::text NOT NULL,
    shipping_address text,
    status text DEFAULT 'queued'::text NOT NULL,
    preparation_photo_url text,
    tracking_carrier text,
    tracking_number text,
    fulfillment_token text NOT NULL,
    payment_status text DEFAULT 'unpaid'::text NOT NULL,
    fulfillment_email_status text,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    tracking_status text,
    tracking_checked_at text,
    target_amount_usd bigint,
    payment_required bigint DEFAULT 0 NOT NULL,
    stripe_payment_intent_id text,
    payment_error text,
    stripe_refund_id text,
    paid_at text,
    trigger text DEFAULT 'manual'::text NOT NULL,
    released_at text
);


--
-- Name: approved_faq; Type: TABLE; Schema: help; Owner: -
--

CREATE TABLE help.approved_faq (
    id text NOT NULL,
    created_at text DEFAULT public.datetime('now'::text) NOT NULL,
    question_id text NOT NULL,
    question_en text NOT NULL,
    question_es text NOT NULL,
    answer_en text NOT NULL,
    answer_es text NOT NULL,
    source_ids text DEFAULT '[]'::text NOT NULL
);


--
-- Name: questions; Type: TABLE; Schema: help; Owner: -
--

CREATE TABLE help.questions (
    id text NOT NULL,
    created_at text DEFAULT public.datetime('now'::text) NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    question text NOT NULL,
    sources text DEFAULT '[]'::text NOT NULL,
    answer text DEFAULT ''::text NOT NULL,
    covered bigint DEFAULT 0 NOT NULL,
    helpful bigint,
    page text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: applications; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.applications (
    id bigint NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    states text NOT NULL,
    companies text NOT NULL,
    years text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'marketplace_apply'::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: marketplace; Owner: -
--

ALTER TABLE marketplace.applications ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME marketplace.applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: card_prefs; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.card_prefs (
    slug text NOT NULL,
    card_theme text DEFAULT 'dark'::text NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.leads (
    id bigint NOT NULL,
    agent_slug text NOT NULL,
    visitor_first_name text NOT NULL,
    visitor_phone text NOT NULL,
    visitor_email text,
    visitor_need text,
    lang text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'verifiedinsurancepros_organic'::text NOT NULL,
    ip text,
    created_at text NOT NULL,
    referrer text DEFAULT ''::text NOT NULL,
    delivery_status text DEFAULT ''::text NOT NULL,
    delivered_lead_id text DEFAULT ''::text NOT NULL
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: marketplace; Owner: -
--

ALTER TABLE marketplace.leads ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME marketplace.leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: privacy_requests; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.privacy_requests (
    id bigint NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    message text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    site text DEFAULT 'verifiedinsurancepros'::text NOT NULL,
    ip text,
    created_at text NOT NULL
);


--
-- Name: privacy_requests_id_seq; Type: SEQUENCE; Schema: marketplace; Owner: -
--

ALTER TABLE marketplace.privacy_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME marketplace.privacy_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: producers; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.producers (
    slug text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    record_json text DEFAULT '{}'::text NOT NULL,
    card_json text DEFAULT '{}'::text NOT NULL,
    headshot_url text DEFAULT ''::text NOT NULL,
    headshot_doc_id text DEFAULT ''::text NOT NULL,
    verified bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    review_note text DEFAULT ''::text NOT NULL,
    source_updated_at bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    approved_by text DEFAULT ''::text NOT NULL,
    approved_by_name text DEFAULT ''::text NOT NULL,
    approved_via text DEFAULT ''::text NOT NULL,
    approved_at bigint DEFAULT 0 NOT NULL,
    republished_at bigint DEFAULT 0 NOT NULL,
    republished_by text DEFAULT ''::text NOT NULL,
    republished_by_name text DEFAULT ''::text NOT NULL,
    republished_via text DEFAULT ''::text NOT NULL,
    republish_note text DEFAULT ''::text NOT NULL,
    unpublished_at bigint DEFAULT 0 NOT NULL,
    unpublished_by text DEFAULT ''::text NOT NULL,
    unpublished_by_name text DEFAULT ''::text NOT NULL,
    unpublished_via text DEFAULT ''::text NOT NULL,
    unpublish_reason text DEFAULT ''::text NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.reviews (
    id bigint NOT NULL,
    slug text NOT NULL,
    stars bigint NOT NULL,
    first_name text NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'site'::text NOT NULL,
    review_date text NOT NULL,
    published bigint DEFAULT 1 NOT NULL,
    ip text,
    created_at text NOT NULL,
    comment_translated text,
    email text,
    phone text
);


--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: marketplace; Owner: -
--

ALTER TABLE marketplace.reviews ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME marketplace.reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: waitlist; Type: TABLE; Schema: marketplace; Owner: -
--

CREATE TABLE marketplace.waitlist (
    id bigint NOT NULL,
    email text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'marketplace_landing'::text NOT NULL,
    created_at text NOT NULL,
    updated_at text
);


--
-- Name: waitlist_id_seq; Type: SEQUENCE; Schema: marketplace; Owner: -
--

ALTER TABLE marketplace.waitlist ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME marketplace.waitlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: acc_appeals; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_appeals (
    id text NOT NULL,
    entry_id text NOT NULL,
    matter_id text NOT NULL,
    appellant_agent_id text NOT NULL,
    reviewer_id_appealed text NOT NULL,
    appeal_officer_id text,
    filed_at bigint NOT NULL,
    deadline_at bigint NOT NULL,
    outcome text,
    decided_at bigint,
    decision_note text
);


--
-- Name: acc_entries; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_entries (
    id text NOT NULL,
    matter_id text NOT NULL,
    agent_id text NOT NULL,
    category text NOT NULL,
    tier text NOT NULL,
    reviewer_id text NOT NULL,
    records_relied_on text DEFAULT '[]'::text NOT NULL,
    determined_at bigint NOT NULL,
    expires_at bigint,
    status text DEFAULT 'active'::text NOT NULL,
    origin text DEFAULT 'review'::text NOT NULL,
    pattern_parent_id text,
    notice_id text
);


--
-- Name: acc_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_events (
    id text NOT NULL,
    matter_id text NOT NULL,
    event_type text NOT NULL,
    actor_id text,
    actor_role text NOT NULL,
    occurred_at bigint NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL
);


--
-- Name: acc_matters; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_matters (
    id text NOT NULL,
    agent_id text NOT NULL,
    category text NOT NULL,
    proposed_tier text,
    state text DEFAULT 'flagged'::text NOT NULL,
    reviewer_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: acc_notices; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_notices (
    id text NOT NULL,
    matter_id text NOT NULL,
    category text NOT NULL,
    proposed_tier text NOT NULL,
    records_cited text DEFAULT '[]'::text NOT NULL,
    sent_at bigint NOT NULL,
    window_closes_at bigint NOT NULL,
    delivery_status text NOT NULL,
    delivery_channel text,
    delivery_detail text,
    responded_at bigint,
    rowid bigint NOT NULL
);


--
-- Name: acc_notices_rowid_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.acc_notices ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.acc_notices_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: acc_records_requests; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_records_requests (
    id text NOT NULL,
    matter_id text NOT NULL,
    agent_id text NOT NULL,
    requested_at bigint NOT NULL,
    fulfilled_at bigint,
    redaction_note text,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: acc_review_disputes; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_review_disputes (
    id text NOT NULL,
    review_ref text NOT NULL,
    agent_id text NOT NULL,
    raised_at bigint NOT NULL,
    ground text NOT NULL,
    ai_flag bigint DEFAULT 0 NOT NULL,
    moderator_id text,
    outcome text,
    decided_at bigint,
    note text
);


--
-- Name: acc_role_designations; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.acc_role_designations (
    id text NOT NULL,
    reviewer_account_id text,
    appeal_officer_account_id text,
    effective_at bigint NOT NULL,
    signed bigint DEFAULT 0 NOT NULL,
    note text,
    rowid bigint NOT NULL
);


--
-- Name: acc_role_designations_rowid_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.acc_role_designations ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.acc_role_designations_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: accounts; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.accounts (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    stripe_customer_id text,
    subscription_status text DEFAULT 'none'::text NOT NULL,
    subscription_id text,
    plan_tier text,
    featured bigint DEFAULT 0 NOT NULL,
    current_period_end bigint,
    cancel_at_period_end bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    role text DEFAULT 'agent'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    billing_mode text DEFAULT 'stripe'::text NOT NULL,
    manual_payment_note text,
    agency_id text,
    seat_role text DEFAULT 'producer'::text NOT NULL,
    trial_started_at bigint,
    trial_ends_at bigint,
    trial_converted_at bigint,
    seat_monthly_cents bigint,
    plan_term text,
    manual_anchor_day bigint,
    manual_bill_cents bigint,
    email_changed_at bigint,
    email_previous text DEFAULT ''::text NOT NULL,
    setter_for_account_id text,
    bundle_kind text,
    bundle_paid_cents bigint,
    bundle_list_cents bigint,
    bundle_started_at bigint,
    bundle_renews_at bigint,
    bundle_payment_ref text,
    seat_prices_json text,
    not_a_person text DEFAULT ''::text NOT NULL,
    usage_payer_customer_id text,
    lead_alert_recipient_id text
);


--
-- Name: additional_agents; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.additional_agents (
    id text NOT NULL,
    account_id text NOT NULL,
    agent_number text DEFAULT ''::text,
    agent_state_license text DEFAULT ''::text,
    agency_number text DEFAULT ''::text,
    agent_phone text DEFAULT ''::text,
    agent_email text DEFAULT ''::text,
    agent_comp_percent text DEFAULT ''::text,
    created_at bigint NOT NULL
);


--
-- Name: agencies; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agencies (
    id text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    owner_account_id text,
    billing_mode text DEFAULT 'manual'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    seat_limit bigint,
    note text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    report_recipient_name text,
    timezone text
);


--
-- Name: agency_team_leads; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agency_team_leads (
    agency_id text NOT NULL,
    leader_account_id text NOT NULL,
    member_account_id text NOT NULL,
    created_at text DEFAULT public.datetime('now'::text) NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    removed_at text,
    removed_by text
);


--
-- Name: agent_document_signatures; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agent_document_signatures (
    id text NOT NULL,
    account_id text NOT NULL,
    document_id text NOT NULL,
    document_version text NOT NULL,
    typed_name text NOT NULL,
    consent_checked bigint DEFAULT 0 NOT NULL,
    signed_at text NOT NULL,
    ip_address text DEFAULT ''::text,
    created_at bigint NOT NULL,
    signature_epoch bigint DEFAULT 0 NOT NULL
);


--
-- Name: agent_phone_numbers; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agent_phone_numbers (
    account_id text NOT NULL,
    e164 text NOT NULL,
    state text DEFAULT ''::text NOT NULL,
    is_primary bigint DEFAULT 0 NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    license_flag text DEFAULT ''::text NOT NULL,
    license_flagged_at bigint,
    forward_to text DEFAULT ''::text NOT NULL,
    inclusion_moved_at bigint,
    non_billable_reason text DEFAULT ''::text NOT NULL,
    rotation_state text DEFAULT 'active'::text NOT NULL,
    rotation_state_at bigint,
    rotation_state_reason text,
    origin text,
    replaces_e164 text,
    cnam_value text,
    cnam_set_at bigint,
    warmup_started_at bigint,
    rowid bigint NOT NULL
);


--
-- Name: agent_phone_numbers_rowid_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.agent_phone_numbers ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.agent_phone_numbers_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_signature_resets; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agent_signature_resets (
    id text NOT NULL,
    account_id text NOT NULL,
    epoch bigint NOT NULL,
    reason text NOT NULL,
    prior_holder text DEFAULT ''::text,
    actor text NOT NULL,
    reset_at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: agent_webrtc_credentials; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agent_webrtc_credentials (
    id text NOT NULL,
    account_id text NOT NULL,
    telnyx_credential_id text NOT NULL,
    sip_username text NOT NULL,
    connection_id text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    revoked_at bigint
);


--
-- Name: agreements; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.agreements (
    id text NOT NULL,
    title text NOT NULL,
    version text NOT NULL,
    source_pdf_r2_key text NOT NULL,
    source_pdf_sha256 text NOT NULL,
    signature_field_spec text NOT NULL,
    esign_disclosure_text_en text NOT NULL,
    esign_disclosure_text_es text NOT NULL,
    is_active bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    created_by text NOT NULL,
    expected_page_count bigint,
    countersign_field_spec text
);


--
-- Name: application_snapshots; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.application_snapshots (
    id text NOT NULL,
    client_id text NOT NULL,
    call_id text DEFAULT ''::text,
    agent_id text DEFAULT ''::text,
    fields_encrypted text NOT NULL,
    recording_ref text DEFAULT ''::text,
    created_at bigint NOT NULL
);


--
-- Name: auth_audit_log; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.auth_audit_log (
    id text NOT NULL,
    account_id text,
    event text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: call_coaching; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.call_coaching (
    call_id text NOT NULL,
    agent_account_id text DEFAULT ''::text NOT NULL,
    coaching_json text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: call_transcripts; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.call_transcripts (
    call_id text NOT NULL,
    agent_account_id text DEFAULT ''::text NOT NULL,
    transcript text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    audio_minutes real DEFAULT 0 NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: client_acknowledgments; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.client_acknowledgments (
    id text NOT NULL,
    client_id text NOT NULL,
    screen_id text NOT NULL,
    screen_version text NOT NULL,
    language text NOT NULL,
    call_id text DEFAULT ''::text,
    agent_id text DEFAULT ''::text,
    acknowledged_at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: coaching_jobs; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.coaching_jobs (
    call_id text NOT NULL,
    agent_account_id text DEFAULT ''::text NOT NULL,
    agent_npn text DEFAULT ''::text NOT NULL,
    agent_name text DEFAULT ''::text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    agent_leg_id text DEFAULT ''::text NOT NULL,
    client_leg_id text DEFAULT ''::text NOT NULL,
    call_started_at text DEFAULT ''::text NOT NULL,
    call_ended_at text DEFAULT ''::text NOT NULL,
    end_reason text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    recording_id text DEFAULT ''::text NOT NULL,
    audio_minutes real DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    client_name text DEFAULT ''::text NOT NULL,
    client_number text DEFAULT ''::text NOT NULL
);


--
-- Name: coaching_rollups; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.coaching_rollups (
    agent_account_id text NOT NULL,
    period_type text NOT NULL,
    period_key text NOT NULL,
    rollup_json text DEFAULT ''::text NOT NULL,
    calls_count bigint DEFAULT 0 NOT NULL,
    stale bigint DEFAULT 1 NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    generated_at bigint DEFAULT 0 NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: compliance_detections; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.compliance_detections (
    id text NOT NULL,
    call_id text NOT NULL,
    pattern_id text NOT NULL,
    matched_text text NOT NULL,
    transcript_line text NOT NULL,
    language text NOT NULL,
    detected_at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: crm_presence; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.crm_presence (
    account_id text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    first text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    phone10 text DEFAULT ''::text NOT NULL,
    st text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'onboarding_self'::text NOT NULL,
    stage text DEFAULT 'self'::text NOT NULL,
    owner_key text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: disclosure_evidence; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.disclosure_evidence (
    id text NOT NULL,
    call_id text NOT NULL,
    agent_id text NOT NULL,
    disclosure_version_id text NOT NULL,
    language text NOT NULL,
    matched_text text NOT NULL,
    matched_at text NOT NULL,
    client_recording_started_at text NOT NULL,
    created_at bigint NOT NULL,
    bridge_connected_at text DEFAULT ''::text NOT NULL,
    detected_at text DEFAULT ''::text NOT NULL,
    gap_seconds real
);


--
-- Name: disclosure_purges; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.disclosure_purges (
    id text NOT NULL,
    call_id text NOT NULL,
    agent_id text DEFAULT ''::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    reason text NOT NULL,
    bridge_connected_at text DEFAULT ''::text NOT NULL,
    purged_at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.documents (
    id text NOT NULL,
    account_id text NOT NULL,
    kind text NOT NULL,
    r2_key text NOT NULL,
    filename text DEFAULT ''::text,
    content_type text DEFAULT ''::text,
    size bigint DEFAULT 0,
    created_at bigint NOT NULL,
    state text DEFAULT ''::text,
    filed_by text DEFAULT ''::text,
    filed_by_name text DEFAULT ''::text,
    filed_via text DEFAULT ''::text,
    deleted_at bigint,
    deleted_by text DEFAULT ''::text,
    deleted_by_name text DEFAULT ''::text,
    deleted_reason text DEFAULT ''::text
);


--
-- Name: email_log; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.email_log (
    id text NOT NULL,
    template text NOT NULL,
    to_email text NOT NULL,
    account_id text,
    critical bigint DEFAULT 0 NOT NULL,
    status text NOT NULL,
    provider_id text,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: envelope_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.envelope_events (
    id text NOT NULL,
    envelope_id text NOT NULL,
    event_type text NOT NULL,
    occurred_at bigint NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: envelope_events_rowid_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.envelope_events ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.envelope_events_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: envelope_otp; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.envelope_otp (
    id text NOT NULL,
    envelope_id text NOT NULL,
    code_hash text NOT NULL,
    sent_to_email text NOT NULL,
    sent_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    verified_at bigint,
    locked_at bigint,
    rowid bigint NOT NULL
);


--
-- Name: envelope_otp_rowid_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.envelope_otp ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.envelope_otp_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: envelopes; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.envelopes (
    id text NOT NULL,
    agreement_id text NOT NULL,
    agent_id text NOT NULL,
    signer_email text NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL,
    source_pdf_sha256_at_send text NOT NULL,
    signer_legal_name text,
    consent_disclosure_lang text,
    sealed_pdf_r2_key text,
    sealed_pdf_sha256 text,
    sent_at bigint NOT NULL,
    signed_at bigint,
    expires_at bigint NOT NULL,
    voided_at bigint,
    void_reason text,
    countersigned_at bigint,
    countersigned_by text,
    countersigner_legal_name text,
    countersigner_email text,
    countersign_mode text,
    countersign_consent_lang text,
    executed_pdf_r2_key text,
    executed_pdf_sha256 text,
    countersign_hold_reason text,
    countersign_hold_at bigint,
    countersign_hold_by text,
    brand text,
    access_token_hash text
);


--
-- Name: eo_status; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.eo_status (
    account_id text NOT NULL,
    alert_stage text DEFAULT ''::text NOT NULL,
    alert_sent_at bigint,
    alert_expiry text DEFAULT ''::text NOT NULL,
    lapsed bigint DEFAULT 0 NOT NULL,
    lapsed_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: evidence_audit_log; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.evidence_audit_log (
    id text NOT NULL,
    actor text NOT NULL,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text DEFAULT ''::text,
    detail text DEFAULT ''::text,
    at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: headshot_finishes; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.headshot_finishes (
    id text NOT NULL,
    account_id text NOT NULL,
    source_document_id text DEFAULT ''::text NOT NULL,
    document_id text NOT NULL,
    sha256 text NOT NULL,
    manifest_json text DEFAULT '{}'::text NOT NULL,
    tool_verdict text DEFAULT ''::text NOT NULL,
    token_hash text NOT NULL,
    expires_at bigint NOT NULL,
    state text DEFAULT 'awaiting'::text NOT NULL,
    decided_at bigint,
    decided_name text DEFAULT ''::text NOT NULL,
    decided_note text DEFAULT ''::text NOT NULL,
    decided_ip text DEFAULT ''::text NOT NULL,
    filed_by text DEFAULT ''::text NOT NULL,
    filed_by_name text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    published_doc_id text DEFAULT ''::text NOT NULL
);


--
-- Name: headshot_jobs; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.headshot_jobs (
    id text NOT NULL,
    account_id text NOT NULL,
    source_document_id text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    prompt_id text DEFAULT ''::text NOT NULL,
    prompt_sha256 text DEFAULT ''::text NOT NULL,
    cost_micros bigint DEFAULT 0 NOT NULL,
    usage_json text DEFAULT '{}'::text NOT NULL,
    finish_id text DEFAULT ''::text NOT NULL,
    asked_by text DEFAULT ''::text NOT NULL,
    asked_by_name text DEFAULT ''::text NOT NULL,
    claimed_at bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    finished_at bigint DEFAULT 0 NOT NULL
);


--
-- Name: headshot_rejections; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.headshot_rejections (
    sha256 text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    finish_id text DEFAULT ''::text NOT NULL,
    rejected_at bigint NOT NULL,
    rejected_name text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL
);


--
-- Name: headshot_spend; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.headshot_spend (
    id text NOT NULL,
    month text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    job_id text DEFAULT ''::text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    quality text DEFAULT ''::text NOT NULL,
    size text DEFAULT ''::text NOT NULL,
    input_text_tokens bigint DEFAULT 0 NOT NULL,
    input_image_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    cost_micros bigint NOT NULL,
    delivered bigint DEFAULT 0 NOT NULL,
    at bigint NOT NULL
);


--
-- Name: headshot_spend_notices; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.headshot_spend_notices (
    month text NOT NULL,
    threshold_micros bigint NOT NULL,
    spend_micros bigint NOT NULL,
    at bigint NOT NULL,
    wire_result text DEFAULT ''::text NOT NULL
);


--
-- Name: impersonation_actions; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.impersonation_actions (
    id text NOT NULL,
    session_id text NOT NULL,
    actor_account_id text NOT NULL,
    actor_name text DEFAULT ''::text NOT NULL,
    target_account_id text NOT NULL,
    target_name text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    surface text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: lead_alert_held_rings; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_alert_held_rings (
    id text NOT NULL,
    account_id text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    held_at bigint NOT NULL,
    release_at bigint NOT NULL,
    held_reason text DEFAULT ''::text NOT NULL,
    local_time text DEFAULT ''::text NOT NULL,
    claimed_at bigint,
    result_json text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: lead_alert_optins; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_alert_optins (
    account_id text NOT NULL,
    email_on bigint DEFAULT 1 NOT NULL,
    voice_on bigint DEFAULT 1 NOT NULL,
    ring_to text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    set_by text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    hold_overnight bigint DEFAULT 0 NOT NULL
);


--
-- Name: lead_alert_probes; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_alert_probes (
    id text NOT NULL,
    account_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_by text DEFAULT ''::text NOT NULL,
    claimed_at bigint,
    result_json text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: lead_alert_recipients; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_alert_recipients (
    id text NOT NULL,
    account_id text NOT NULL,
    email text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    lang text DEFAULT ''::text NOT NULL,
    active bigint DEFAULT 1 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: lead_alert_rings; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_alert_rings (
    id text NOT NULL,
    account_id text NOT NULL,
    lead_id text DEFAULT ''::text NOT NULL,
    event text NOT NULL,
    outcome text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    ring_to text DEFAULT ''::text NOT NULL,
    ring_from text DEFAULT ''::text NOT NULL,
    call_control_id text DEFAULT ''::text NOT NULL,
    detail_json text DEFAULT ''::text NOT NULL,
    occurred_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: lead_views; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.lead_views (
    id text NOT NULL,
    lead_id text NOT NULL,
    viewed_at text NOT NULL,
    ip text,
    country text,
    city text,
    user_agent text,
    created_at bigint NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.leads (
    id text NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    source text DEFAULT 'vsl'::text NOT NULL,
    verified bigint DEFAULT 0 NOT NULL,
    verified_at text,
    verified_email text,
    first_ip text,
    first_country text,
    first_city text,
    first_user_agent text,
    first_seen text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: leads_interest; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.leads_interest (
    id text NOT NULL,
    email text NOT NULL,
    source text DEFAULT 'pbgcopilot.com'::text NOT NULL,
    lang text,
    ip text,
    country text,
    city text,
    user_agent text,
    submissions bigint DEFAULT 1 NOT NULL,
    first_submitted_at text NOT NULL,
    last_submitted_at text NOT NULL,
    notify_status text,
    notify_id text,
    notify_error text,
    created_at bigint NOT NULL,
    external_id text,
    kind text,
    name text,
    phone text,
    note text,
    company text,
    crm_status text,
    crm_http bigint,
    crm_error text,
    crm_attempts bigint DEFAULT 0 NOT NULL,
    crm_last_attempt_at text
);


--
-- Name: license_confirmations; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.license_confirmations (
    account_id text NOT NULL,
    state text NOT NULL,
    active bigint DEFAULT 0 NOT NULL,
    confirmed_at bigint,
    confirmed_by text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: license_status; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.license_status (
    account_id text NOT NULL,
    state text NOT NULL,
    lapsed bigint DEFAULT 0 NOT NULL,
    lapsed_at bigint,
    alert_stage text DEFAULT ''::text NOT NULL,
    alert_sent_at bigint,
    alert_expiry text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: license_sweep_state; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.license_sweep_state (
    id bigint NOT NULL,
    last_run_at bigint DEFAULT 0 NOT NULL,
    last_result text DEFAULT ''::text NOT NULL,
    CONSTRAINT license_sweep_state_id_check CHECK ((id = 1))
);


--
-- Name: license_withdrawals; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.license_withdrawals (
    account_id text NOT NULL,
    state text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    withdrawn_by text DEFAULT ''::text NOT NULL,
    withdrawn_by_name text DEFAULT ''::text NOT NULL,
    withdrawn_via text DEFAULT ''::text NOT NULL,
    withdrawn_at bigint NOT NULL,
    license_number text DEFAULT ''::text NOT NULL,
    expiry_date text DEFAULT ''::text NOT NULL,
    was_confirmed bigint DEFAULT 0 NOT NULL,
    number_e164 text DEFAULT ''::text NOT NULL,
    number_decision text DEFAULT ''::text NOT NULL,
    document_ids text DEFAULT '[]'::text NOT NULL,
    producer_slug text DEFAULT ''::text NOT NULL,
    restored_at bigint,
    restored_by text DEFAULT ''::text NOT NULL
);


--
-- Name: licenses; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.licenses (
    id text NOT NULL,
    account_id text NOT NULL,
    state text NOT NULL,
    license_number text DEFAULT ''::text,
    expiry_date text DEFAULT ''::text,
    created_at bigint NOT NULL,
    filed_by text DEFAULT ''::text,
    filed_by_name text DEFAULT ''::text,
    filed_via text DEFAULT ''::text,
    expiry_read_by text DEFAULT ''::text,
    edited_at bigint,
    edited_by text DEFAULT ''::text,
    edited_by_name text DEFAULT ''::text
);


--
-- Name: login_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.login_events (
    id text NOT NULL,
    account_id text NOT NULL,
    session_id text NOT NULL,
    at bigint NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    device_hint text DEFAULT ''::text NOT NULL,
    ua_family text DEFAULT ''::text NOT NULL,
    country text DEFAULT ''::text NOT NULL,
    region text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    latitude real,
    longitude real,
    displaced_session_id text,
    displaced_device_hint text DEFAULT ''::text NOT NULL,
    notice_sent bigint DEFAULT 0 NOT NULL,
    client text DEFAULT ''::text NOT NULL
);


--
-- Name: money_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.money_events (
    id text NOT NULL,
    family text NOT NULL,
    kind text NOT NULL,
    occurred_at bigint NOT NULL,
    account_id text,
    email text,
    person text,
    company text,
    amount_cents bigint,
    currency text DEFAULT 'usd'::text NOT NULL,
    how text DEFAULT 'stripe'::text NOT NULL,
    tier text,
    term text,
    price_ok bigint,
    price_note text,
    stripe_object text,
    detail text,
    dedupe_key text NOT NULL,
    notified bigint DEFAULT 0 NOT NULL,
    notify_result text,
    notified_at bigint,
    created_at bigint NOT NULL
);


--
-- Name: number_accrual_state; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.number_accrual_state (
    id bigint NOT NULL,
    last_run_at bigint DEFAULT 0 NOT NULL,
    CONSTRAINT number_accrual_state_id_check CHECK ((id = 1))
);


--
-- Name: number_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.number_events (
    id bigint NOT NULL,
    dedupe_key text NOT NULL,
    kind text NOT NULL,
    at bigint NOT NULL,
    e164 text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    actor text DEFAULT ''::text NOT NULL,
    via text DEFAULT ''::text NOT NULL,
    reason_code text DEFAULT ''::text NOT NULL,
    detail_json text DEFAULT '{}'::text NOT NULL,
    received_at bigint NOT NULL
);


--
-- Name: number_events_id_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.number_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.number_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: number_registrations; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.number_registrations (
    e164 text NOT NULL,
    program text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    status text DEFAULT ''::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    reason_code text
);


--
-- Name: number_releases; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.number_releases (
    account_id text NOT NULL,
    e164 text NOT NULL,
    state text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    requested_by text DEFAULT ''::text NOT NULL,
    requested_by_name text DEFAULT ''::text NOT NULL,
    requested_via text DEFAULT ''::text NOT NULL,
    requested_at bigint NOT NULL,
    acted_at bigint,
    detail text DEFAULT ''::text NOT NULL,
    reason_code text DEFAULT ''::text NOT NULL
);


--
-- Name: number_requests; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.number_requests (
    account_id text NOT NULL,
    state text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    who_pays text DEFAULT ''::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    e164 text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    reason_code text DEFAULT ''::text NOT NULL,
    retry_after bigint DEFAULT 0 NOT NULL,
    origin text DEFAULT 'license'::text NOT NULL,
    purchased_by text DEFAULT ''::text NOT NULL,
    released_at bigint,
    area_pin text DEFAULT ''::text NOT NULL
);


--
-- Name: password_resets; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.password_resets (
    id text NOT NULL,
    account_id text NOT NULL,
    token_hash text NOT NULL,
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    used_at bigint
);


--
-- Name: platform_waitlist; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.platform_waitlist (
    id text NOT NULL,
    email text NOT NULL,
    source text DEFAULT 'pbgcopilot.com'::text NOT NULL,
    ip text,
    country text,
    city text,
    user_agent text,
    signed_up_at text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: pool_line_requests; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.pool_line_requests (
    id bigint NOT NULL,
    account_id text NOT NULL,
    state text NOT NULL,
    reason_code text DEFAULT 'top_up'::text NOT NULL,
    replaces_e164 text DEFAULT ''::text NOT NULL,
    trigger_source text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    who_pays text DEFAULT ''::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    min_outbound bigint DEFAULT 4 NOT NULL,
    usable_at_ask bigint DEFAULT 0 NOT NULL,
    e164 text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    fail_reason_code text DEFAULT ''::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pool_line_requests_id_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.pool_line_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.pool_line_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: privacy_requests; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.privacy_requests (
    id bigint NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    message text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    site text DEFAULT 'pbgcopilot'::text NOT NULL,
    ip text,
    created_at bigint NOT NULL
);


--
-- Name: privacy_requests_id_seq; Type: SEQUENCE; Schema: onboarding; Owner: -
--

ALTER TABLE onboarding.privacy_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME onboarding.privacy_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: producer_documents; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.producer_documents (
    id text NOT NULL,
    producer_slug text NOT NULL,
    kind text DEFAULT 'license'::text NOT NULL,
    r2_key text NOT NULL,
    filename text DEFAULT ''::text NOT NULL,
    content_type text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    state text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    filed_by text DEFAULT ''::text NOT NULL,
    filed_by_name text DEFAULT ''::text NOT NULL,
    filed_via text DEFAULT ''::text NOT NULL
);


--
-- Name: producer_licenses; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.producer_licenses (
    producer_slug text NOT NULL,
    state text NOT NULL,
    license_number text DEFAULT ''::text NOT NULL,
    number_is_npn bigint DEFAULT 0 NOT NULL,
    issued text DEFAULT ''::text NOT NULL,
    expiry_date text DEFAULT ''::text NOT NULL,
    expiry_read_by text DEFAULT ''::text NOT NULL,
    filed_by text DEFAULT ''::text NOT NULL,
    filed_by_name text DEFAULT ''::text NOT NULL,
    filed_via text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: producer_seeds; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.producer_seeds (
    account_id text NOT NULL,
    slug text DEFAULT ''::text NOT NULL,
    record_json text DEFAULT '{}'::text NOT NULL,
    card_json text DEFAULT '{}'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    verified bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    seed_delivery text DEFAULT ''::text NOT NULL,
    seed_delivery_at bigint DEFAULT 0 NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.profiles (
    account_id text NOT NULL,
    first_name text DEFAULT ''::text,
    middle_name text DEFAULT ''::text,
    last_name text DEFAULT ''::text,
    agent_number text DEFAULT ''::text,
    npn text DEFAULT ''::text,
    agency_number text DEFAULT ''::text,
    agency_name text DEFAULT ''::text,
    agent_phone text DEFAULT ''::text,
    agent_email text DEFAULT ''::text,
    agent_comp_percent text DEFAULT '100'::text,
    eo_carrier text DEFAULT ''::text,
    eo_expiry text DEFAULT ''::text,
    verification_status text DEFAULT 'pending'::text NOT NULL,
    bio_answers text DEFAULT '{}'::text,
    language text DEFAULT 'en'::text,
    completed bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    date_of_birth text DEFAULT ''::text,
    address_line1 text DEFAULT ''::text,
    address_line2 text DEFAULT ''::text,
    address_city text DEFAULT ''::text,
    address_state text DEFAULT ''::text,
    address_zip text DEFAULT ''::text,
    eo_review bigint DEFAULT 0 NOT NULL,
    mailing_line1 text DEFAULT ''::text,
    mailing_line2 text DEFAULT ''::text,
    mailing_city text DEFAULT ''::text,
    mailing_state text DEFAULT ''::text,
    mailing_zip text DEFAULT ''::text,
    social_linkedin text DEFAULT ''::text,
    social_instagram text DEFAULT ''::text,
    social_facebook text DEFAULT ''::text,
    social_whatsapp text DEFAULT ''::text,
    card_handle text DEFAULT ''::text,
    card_language text DEFAULT ''::text,
    callback_catcher text DEFAULT ''::text NOT NULL,
    eo_policy_number text DEFAULT ''::text NOT NULL,
    eo_limit text DEFAULT ''::text NOT NULL,
    mailing_phone text DEFAULT ''::text,
    social_tiktok text DEFAULT ''::text,
    social_youtube text DEFAULT ''::text,
    social_website text DEFAULT ''::text
);


--
-- Name: rotation_line_requests; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.rotation_line_requests (
    account_id text NOT NULL,
    state text NOT NULL,
    slot bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    who_pays text DEFAULT ''::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    requested_pace bigint DEFAULT 0 NOT NULL,
    e164 text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    reason_code text DEFAULT ''::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: script_master; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.script_master (
    id text NOT NULL,
    brand text NOT NULL,
    language text NOT NULL,
    version bigint NOT NULL,
    effective_date text NOT NULL,
    content_encrypted text NOT NULL,
    created_at bigint NOT NULL,
    variant text DEFAULT 'master'::text NOT NULL
);


--
-- Name: seat_offboard_notices; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.seat_offboard_notices (
    account_id text NOT NULL,
    notice text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    claimed_at bigint NOT NULL,
    sent_at bigint,
    updated_at bigint NOT NULL
);


--
-- Name: seat_offboard_schedule; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.seat_offboard_schedule (
    account_id text NOT NULL,
    due_at bigint NOT NULL,
    alarm_at bigint NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    ruled_by text DEFAULT ''::text NOT NULL,
    requested_by text DEFAULT ''::text NOT NULL,
    subscription_id text DEFAULT ''::text NOT NULL,
    alarm_status text DEFAULT ''::text NOT NULL,
    alarm_sent_at bigint,
    alarm_error text DEFAULT ''::text NOT NULL,
    alarm_text text DEFAULT ''::text NOT NULL,
    ran_at bigint,
    attempts bigint DEFAULT 0 NOT NULL,
    result_json text DEFAULT '{}'::text NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: seat_offboard_sweep_state; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.seat_offboard_sweep_state (
    id bigint NOT NULL,
    last_run_at bigint DEFAULT 0 NOT NULL,
    CONSTRAINT seat_offboard_sweep_state_id_check CHECK ((id = 1))
);


--
-- Name: seat_trial_notices; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.seat_trial_notices (
    account_id text NOT NULL,
    notice text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    last_error text,
    claimed_at bigint NOT NULL,
    sent_at bigint,
    updated_at bigint NOT NULL
);


--
-- Name: seat_trial_sweep_state; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.seat_trial_sweep_state (
    id bigint NOT NULL,
    last_run_at bigint DEFAULT 0 NOT NULL,
    CONSTRAINT seat_trial_sweep_state_id_check CHECK ((id = 1))
);


--
-- Name: sessions; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.sessions (
    id text NOT NULL,
    account_id text NOT NULL,
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    revoked_at bigint,
    revoked_reason text,
    device_hint text DEFAULT ''::text NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    surface text DEFAULT ''::text NOT NULL,
    impersonated_by text,
    impersonator_session_id text
);


--
-- Name: signdesk_routes; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.signdesk_routes (
    id text NOT NULL,
    agreement_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    current_step bigint DEFAULT 1 NOT NULL,
    current_envelope_id text,
    steps text NOT NULL,
    countersign_spec text,
    lang text,
    title text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    created_by text NOT NULL
);


--
-- Name: signdesk_templates; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.signdesk_templates (
    id text NOT NULL,
    name text NOT NULL,
    agreement_id text NOT NULL,
    placements text NOT NULL,
    lang text,
    created_at bigint NOT NULL,
    created_by text NOT NULL
);


--
-- Name: signing_handoffs; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.signing_handoffs (
    id text NOT NULL,
    session_id text NOT NULL,
    created_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    used_at bigint
);


--
-- Name: unipile_connections; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.unipile_connections (
    account_id text NOT NULL,
    unipile_account_id text,
    provider text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'none'::text NOT NULL,
    connect_token_hash text,
    connect_expires_at bigint,
    last_error text,
    connected_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: usage_events; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.usage_events (
    id text NOT NULL,
    account_id text NOT NULL,
    kind text NOT NULL,
    quantity real NOT NULL,
    unit text NOT NULL,
    occurred_at text NOT NULL,
    source text NOT NULL,
    idempotency_key text NOT NULL,
    reported_to_stripe_at text,
    created_at bigint NOT NULL,
    voided_at bigint,
    voided_reason text
);


--
-- Name: usage_report_runs; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.usage_report_runs (
    id text NOT NULL,
    kind text DEFAULT 'run'::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    ok bigint DEFAULT 0 NOT NULL,
    considered bigint DEFAULT 0 NOT NULL,
    reported bigint DEFAULT 0 NOT NULL,
    skipped bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    cents bigint DEFAULT 0 NOT NULL,
    moved text DEFAULT '[]'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    told text DEFAULT ''::text NOT NULL,
    ran_at bigint NOT NULL
);


--
-- Name: usage_totals_monthly; Type: VIEW; Schema: onboarding; Owner: -
--

CREATE VIEW onboarding.usage_totals_monthly AS
 SELECT account_id,
    kind,
    unit,
    to_char((occurred_at)::timestamp without time zone, 'YYYY-MM'::text) AS period_month,
    sum(
        CASE
            WHEN (voided_at IS NULL) THEN quantity
            ELSE (0)::real
        END) AS total_quantity,
    count(*) AS event_count,
    sum(
        CASE
            WHEN ((reported_to_stripe_at IS NULL) AND (voided_at IS NULL)) THEN 1
            ELSE 0
        END) AS unreported_count,
    sum(
        CASE
            WHEN (NOT (voided_at IS NULL)) THEN 1
            ELSE 0
        END) AS voided_count,
    sum(
        CASE
            WHEN (NOT (voided_at IS NULL)) THEN quantity
            ELSE (0)::real
        END) AS voided_quantity
   FROM onboarding.usage_events
  GROUP BY account_id, kind, unit, (to_char((occurred_at)::timestamp without time zone, 'YYYY-MM'::text));


--
-- Name: vcard_chat_usage; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.vcard_chat_usage (
    bucket text NOT NULL,
    n bigint DEFAULT 0 NOT NULL,
    expires bigint NOT NULL
);


--
-- Name: vcard_interest; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.vcard_interest (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    source text DEFAULT 'myaivcard.com'::text NOT NULL,
    lang text,
    ip text,
    country text,
    city text,
    user_agent text,
    submissions bigint DEFAULT 1 NOT NULL,
    first_submitted_at text NOT NULL,
    last_submitted_at text NOT NULL,
    notify_status text,
    notify_id text,
    notify_error text,
    created_at bigint NOT NULL
);


--
-- Name: vip_producers; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.vip_producers (
    slug text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    npn text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    resident_state text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    record_verified bigint,
    record_checked_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: vsl_verification; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.vsl_verification (
    email text NOT NULL,
    code_hash text NOT NULL,
    expires_at bigint NOT NULL,
    attempts bigint DEFAULT 0 NOT NULL,
    send_count bigint DEFAULT 0 NOT NULL,
    last_sent_at bigint NOT NULL,
    ip text,
    created_at bigint NOT NULL
);


--
-- Name: welcome_sends; Type: TABLE; Schema: onboarding; Owner: -
--

CREATE TABLE onboarding.welcome_sends (
    account_id text NOT NULL,
    claim_reason text DEFAULT 'agreement_completed'::text NOT NULL,
    claimed_at bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    language text DEFAULT ''::text NOT NULL,
    pdf_bytes bigint,
    provider_id text,
    attempts bigint DEFAULT 0 NOT NULL,
    last_error text,
    sent_at bigint,
    updated_at bigint NOT NULL,
    r2_key text,
    r2_origin text,
    resent_count bigint DEFAULT 0 NOT NULL,
    last_resent_at bigint
);


--
-- Name: aws_adapter_probe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aws_adapter_probe (
    id text NOT NULL,
    value text,
    flag bigint DEFAULT 0 NOT NULL
);


--
-- Name: pbg_asset_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_asset_jobs (
    id uuid NOT NULL,
    slug text NOT NULL,
    draft boolean NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    requested_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    error_code text,
    CONSTRAINT pbg_asset_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'complete'::text, 'failed'::text])))
);


--
-- Name: pbg_aws_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_aws_migrations (
    name text NOT NULL,
    sha256 text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pbg_corporate_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_corporate_sessions (
    key text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: pbg_import_originals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_import_originals (
    schema_name text NOT NULL,
    table_name text NOT NULL,
    source_rowid bigint NOT NULL,
    column_name text NOT NULL,
    original_value jsonb NOT NULL
);


--
-- Name: pbg_phone_proof; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_phone_proof (
    owner text NOT NULL,
    kind text NOT NULL,
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    ended_at timestamp with time zone,
    event_types text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: pbg_published_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_published_assets (
    surface text NOT NULL,
    path text NOT NULL,
    slug text NOT NULL,
    object_key text NOT NULL,
    sha256 text NOT NULL,
    size bigint NOT NULL,
    content_type text NOT NULL,
    build_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT pbg_published_assets_surface_check CHECK ((surface = ANY (ARRAY['marketplace'::text, 'card'::text])))
);


--
-- Name: pbg_room_alarms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_room_alarms (
    room text NOT NULL,
    due bigint NOT NULL
);


--
-- Name: pbg_room_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_room_state (
    room text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL
);


--
-- Name: pbg_state_appends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_state_appends (
    sequence bigint NOT NULL,
    path text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: pbg_state_appends_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pbg_state_appends ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pbg_state_appends_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pbg_state_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_state_documents (
    path text NOT NULL,
    content text NOT NULL,
    document jsonb,
    mode integer DEFAULT 384 NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: pbg_state_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_state_media (
    path text NOT NULL,
    object_key text NOT NULL,
    version_id text,
    sha256 text NOT NULL,
    size bigint NOT NULL,
    mode integer DEFAULT 384 NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: pbg_validation_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pbg_validation_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    category text NOT NULL,
    status text NOT NULL,
    recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    message_type text,
    CONSTRAINT pbg_validation_events_status_check CHECK ((status = 'blocked'::text))
);


--
-- Name: agent_meeting_items; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.agent_meeting_items (
    id text NOT NULL,
    meeting_id text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'action'::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    seq bigint DEFAULT 0 NOT NULL,
    done bigint DEFAULT 0 NOT NULL,
    done_at bigint DEFAULT 0 NOT NULL,
    done_by_operator text DEFAULT ''::text NOT NULL,
    done_by_name text DEFAULT ''::text NOT NULL,
    created_at bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: agent_meeting_items_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.agent_meeting_items ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.agent_meeting_items_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_meeting_transcripts; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.agent_meeting_transcripts (
    meeting_id text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    captured_at bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: agent_meeting_transcripts_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.agent_meeting_transcripts ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.agent_meeting_transcripts_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_meetings; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.agent_meetings (
    id text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    agent_email text DEFAULT ''::text NOT NULL,
    agent_name text DEFAULT ''::text NOT NULL,
    zoom_meeting_id text DEFAULT ''::text NOT NULL,
    zoom_uuid text DEFAULT ''::text NOT NULL,
    zoom_host_user_id text DEFAULT ''::text NOT NULL,
    zoom_host_email text DEFAULT ''::text NOT NULL,
    topic text DEFAULT ''::text NOT NULL,
    agenda text DEFAULT ''::text NOT NULL,
    join_url text DEFAULT ''::text NOT NULL,
    start_at bigint DEFAULT 0 NOT NULL,
    duration_minutes bigint DEFAULT 30 NOT NULL,
    timezone text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    created_by_operator text DEFAULT ''::text NOT NULL,
    created_by_name text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    recording_play_url text DEFAULT ''::text NOT NULL,
    recording_share_url text DEFAULT ''::text NOT NULL,
    recording_passcode text DEFAULT ''::text NOT NULL,
    recording_duration bigint DEFAULT 0 NOT NULL,
    recorded_at bigint DEFAULT 0 NOT NULL,
    summary_text text DEFAULT ''::text NOT NULL,
    summary_model text DEFAULT ''::text NOT NULL,
    summarized_at bigint DEFAULT 0 NOT NULL,
    harvest_note text DEFAULT ''::text NOT NULL,
    harvest_attempts bigint DEFAULT 0 NOT NULL,
    last_harvest_at bigint DEFAULT 0 NOT NULL,
    no_recording_alerted_at bigint DEFAULT 0 NOT NULL,
    created_at bigint DEFAULT 0 NOT NULL,
    updated_at bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: agent_meetings_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.agent_meetings ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.agent_meetings_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_actions; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_actions (
    id text NOT NULL,
    case_id text NOT NULL,
    action text NOT NULL,
    risk text NOT NULL,
    recipe_slug text DEFAULT ''::text NOT NULL,
    actor text DEFAULT 'system'::text NOT NULL,
    status text NOT NULL,
    request text DEFAULT '{}'::text NOT NULL,
    result text DEFAULT '{}'::text NOT NULL,
    created_at bigint NOT NULL,
    operator_id text DEFAULT ''::text NOT NULL,
    operator_name text DEFAULT ''::text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_actions_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_actions ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_actions_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_activation_docs; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_activation_docs (
    id text NOT NULL,
    activation_id text NOT NULL,
    kind text NOT NULL,
    state text DEFAULT ''::text NOT NULL,
    filename text DEFAULT ''::text NOT NULL,
    content_type text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    body_b64 text DEFAULT ''::text NOT NULL,
    uploaded_by text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_activation_docs_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_activation_docs ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_activation_docs_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_activation_steps; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_activation_steps (
    id text NOT NULL,
    activation_id text NOT NULL,
    step text NOT NULL,
    "position" bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_activation_steps_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_activation_steps ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_activation_steps_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_activations; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_activations (
    id text NOT NULL,
    status text DEFAULT 'pending_approval'::text NOT NULL,
    full_legal_name text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    cell text DEFAULT ''::text NOT NULL,
    npn text DEFAULT ''::text NOT NULL,
    agency_name text DEFAULT ''::text NOT NULL,
    primary_state text DEFAULT ''::text NOT NULL,
    states text DEFAULT '[]'::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    payment_amount text DEFAULT ''::text NOT NULL,
    payment_channel text DEFAULT ''::text NOT NULL,
    payment_note text DEFAULT ''::text NOT NULL,
    membership_start text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    headshot_pending bigint DEFAULT 0 NOT NULL,
    requested_by_operator text DEFAULT ''::text NOT NULL,
    requested_by_name text DEFAULT ''::text NOT NULL,
    requested_via text DEFAULT ''::text NOT NULL,
    approval_id text DEFAULT ''::text NOT NULL,
    jarvis_case text DEFAULT ''::text NOT NULL,
    notified text DEFAULT ''::text NOT NULL,
    decided_by text DEFAULT ''::text NOT NULL,
    decided_by_operator text DEFAULT ''::text NOT NULL,
    decided_via text DEFAULT ''::text NOT NULL,
    decided_at bigint,
    decline_reason text DEFAULT ''::text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    number_e164 text DEFAULT ''::text NOT NULL,
    vip_url text DEFAULT ''::text NOT NULL,
    card_url text DEFAULT ''::text NOT NULL,
    blocked_reason text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    claimed_at bigint DEFAULT 0 NOT NULL,
    claim_mark text DEFAULT ''::text NOT NULL,
    finished_at bigint,
    seat_role text DEFAULT 'producer'::text NOT NULL,
    trial_days bigint DEFAULT 0 NOT NULL,
    seat_monthly_cents bigint,
    rowid bigint NOT NULL
);


--
-- Name: support_activations_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_activations ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_activations_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_approvals; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_approvals (
    id text NOT NULL,
    case_id text NOT NULL,
    action text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    request text DEFAULT '{}'::text NOT NULL,
    asked_by text DEFAULT 'system'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notified text DEFAULT 'none'::text NOT NULL,
    decided_by text DEFAULT ''::text NOT NULL,
    decided_at bigint,
    created_at bigint NOT NULL,
    jarvis_case text DEFAULT ''::text NOT NULL,
    decided_by_operator text DEFAULT ''::text NOT NULL,
    decided_via text DEFAULT ''::text NOT NULL,
    asked_by_operator text DEFAULT ''::text NOT NULL,
    asked_by_name text DEFAULT ''::text NOT NULL,
    decline_reason text DEFAULT ''::text NOT NULL,
    notified_at bigint,
    reminded_at bigint,
    reminder_count bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_approvals_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_approvals ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_approvals_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_cases; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_cases (
    id text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    agent_email text DEFAULT ''::text NOT NULL,
    agent_name text DEFAULT ''::text NOT NULL,
    agency_name text DEFAULT ''::text NOT NULL,
    plan_tier text DEFAULT ''::text NOT NULL,
    tier text DEFAULT 'standard'::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    channel text DEFAULT 'agent'::text NOT NULL,
    subject text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    outcome text DEFAULT ''::text NOT NULL,
    recipe_slug text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    resolved_at bigint,
    agent_seen_at bigint DEFAULT 0 NOT NULL,
    opened_by_operator text DEFAULT ''::text NOT NULL,
    opened_by_name text DEFAULT ''::text NOT NULL,
    stage text DEFAULT ''::text NOT NULL,
    stage_at bigint,
    stage_by text DEFAULT ''::text NOT NULL,
    stage_by_name text DEFAULT ''::text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_cases_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_cases ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_cases_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_issues; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_issues (
    id text NOT NULL,
    account_id text DEFAULT ''::text NOT NULL,
    affects text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'other'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    filed_by text DEFAULT ''::text NOT NULL,
    filed_by_name text DEFAULT ''::text NOT NULL,
    shot_key text DEFAULT ''::text NOT NULL,
    shot_type text DEFAULT ''::text NOT NULL,
    shot_size bigint DEFAULT 0 NOT NULL,
    escalated text DEFAULT 'none'::text NOT NULL,
    escalated_at bigint,
    jarvis_case text DEFAULT ''::text NOT NULL,
    resolution text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    resolved_at bigint,
    resolved_by text DEFAULT ''::text NOT NULL,
    resolved_by_name text DEFAULT ''::text NOT NULL,
    reopened_at bigint,
    reopened_by text DEFAULT ''::text NOT NULL,
    reopened_by_name text DEFAULT ''::text NOT NULL,
    last_change_at bigint DEFAULT 0 NOT NULL,
    last_change_kind text DEFAULT ''::text NOT NULL,
    last_change_by text DEFAULT ''::text NOT NULL,
    last_change_by_name text DEFAULT ''::text NOT NULL,
    owner_operator text DEFAULT ''::text NOT NULL,
    owner_operator_name text DEFAULT ''::text NOT NULL,
    owned_at bigint,
    filed_via text DEFAULT 'console'::text NOT NULL,
    stage text DEFAULT ''::text NOT NULL,
    stage_at bigint,
    stage_by text DEFAULT ''::text NOT NULL,
    stage_by_name text DEFAULT ''::text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_issues_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_issues ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_issues_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_jarvis_costs; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_jarvis_costs (
    id text NOT NULL,
    at bigint DEFAULT 0 NOT NULL,
    thread_id text DEFAULT ''::text NOT NULL,
    operator_id text DEFAULT ''::text NOT NULL,
    operator_name text DEFAULT ''::text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    input_units bigint DEFAULT 0 NOT NULL,
    output_units bigint DEFAULT 0 NOT NULL,
    calls bigint DEFAULT 0 NOT NULL,
    usd real DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_jarvis_costs_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_jarvis_costs ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_jarvis_costs_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_jarvis_threads; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_jarvis_threads (
    id text NOT NULL,
    operator_id text DEFAULT ''::text NOT NULL,
    operator_name text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    subject_account_id text DEFAULT ''::text NOT NULL,
    subject_name text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'es'::text NOT NULL,
    started_at bigint DEFAULT 0 NOT NULL,
    last_at bigint DEFAULT 0 NOT NULL,
    asked bigint DEFAULT 0 NOT NULL,
    usd real DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_jarvis_threads_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_jarvis_threads ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_jarvis_threads_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_jarvis_turns; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_jarvis_turns (
    id text NOT NULL,
    thread_id text DEFAULT ''::text NOT NULL,
    seq bigint DEFAULT 0 NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    shown text DEFAULT ''::text NOT NULL,
    at bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_jarvis_turns_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_jarvis_turns ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_jarvis_turns_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_mail_log; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_mail_log (
    id text NOT NULL,
    case_id text DEFAULT ''::text NOT NULL,
    kind text NOT NULL,
    to_email text DEFAULT ''::text NOT NULL,
    door text DEFAULT ''::text NOT NULL,
    outcome text DEFAULT ''::text NOT NULL,
    http_status bigint DEFAULT 0 NOT NULL,
    record_proof bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_mail_log_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_mail_log ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_mail_log_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_messages; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_messages (
    id text NOT NULL,
    case_id text NOT NULL,
    role text NOT NULL,
    body text NOT NULL,
    lang text DEFAULT ''::text NOT NULL,
    grounding text DEFAULT '{}'::text NOT NULL,
    created_at bigint NOT NULL,
    operator_id text DEFAULT ''::text NOT NULL,
    operator_name text DEFAULT ''::text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_messages_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_messages ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_messages_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_notes; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_notes (
    id text NOT NULL,
    account_id text NOT NULL,
    body text NOT NULL,
    author text DEFAULT ''::text NOT NULL,
    author_name text DEFAULT ''::text NOT NULL,
    supersedes text DEFAULT ''::text NOT NULL,
    superseded_by text DEFAULT ''::text NOT NULL,
    deleted_at bigint,
    deleted_by text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_notes_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_notes ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_notes_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_operator_events; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_operator_events (
    id text NOT NULL,
    operator_id text DEFAULT ''::text NOT NULL,
    operator_name text DEFAULT ''::text NOT NULL,
    kind text NOT NULL,
    via text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    notified text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_operator_events_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_operator_events ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_operator_events_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_operators; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_operators (
    id text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    password_hash text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    created_at bigint NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    updated_at bigint NOT NULL,
    password_changed_at bigint DEFAULT 0 NOT NULL,
    last_seen_at bigint DEFAULT 0 NOT NULL,
    deactivated_at bigint,
    deactivated_by text DEFAULT ''::text NOT NULL,
    issues_seen_at bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_operators_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_operators ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_operators_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_ops_requests; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_ops_requests (
    id text NOT NULL,
    status text DEFAULT 'pending_approval'::text NOT NULL,
    action text NOT NULL,
    params text DEFAULT '{}'::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    lang text DEFAULT 'en'::text NOT NULL,
    subject_account_id text DEFAULT ''::text NOT NULL,
    subject_email text DEFAULT ''::text NOT NULL,
    subject_label text DEFAULT ''::text NOT NULL,
    requested_by_operator text DEFAULT ''::text NOT NULL,
    requested_by_name text DEFAULT ''::text NOT NULL,
    requested_via text DEFAULT ''::text NOT NULL,
    approval_id text DEFAULT ''::text NOT NULL,
    jarvis_case text DEFAULT ''::text NOT NULL,
    notified text DEFAULT ''::text NOT NULL,
    decided_by text DEFAULT ''::text NOT NULL,
    decided_by_operator text DEFAULT ''::text NOT NULL,
    decided_via text DEFAULT ''::text NOT NULL,
    decided_at bigint,
    decline_reason text DEFAULT ''::text NOT NULL,
    result text DEFAULT '{}'::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    expires_at bigint DEFAULT 0 NOT NULL,
    claimed_at bigint DEFAULT 0 NOT NULL,
    claim_mark text DEFAULT ''::text NOT NULL,
    finished_at bigint,
    rowid bigint NOT NULL
);


--
-- Name: support_ops_requests_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_ops_requests ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_ops_requests_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_recipes; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_recipes (
    id text NOT NULL,
    slug text NOT NULL,
    title_en text DEFAULT ''::text NOT NULL,
    title_es text DEFAULT ''::text NOT NULL,
    matcher text DEFAULT '{}'::text NOT NULL,
    steps text DEFAULT '[]'::text NOT NULL,
    origin text DEFAULT 'file'::text NOT NULL,
    source_case_id text DEFAULT ''::text NOT NULL,
    runs bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_recipes_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_recipes ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_recipes_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_standing_marks; Type: TABLE; Schema: support; Owner: -
--

CREATE TABLE support.support_standing_marks (
    id text NOT NULL,
    account_id text NOT NULL,
    item_key text NOT NULL,
    subject text DEFAULT ''::text NOT NULL,
    marked_by text DEFAULT ''::text NOT NULL,
    marked_by_name text DEFAULT ''::text NOT NULL,
    marked_at bigint NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    undone_at bigint,
    undone_by text DEFAULT ''::text NOT NULL,
    undone_by_name text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: support_standing_marks_rowid_seq; Type: SEQUENCE; Schema: support; Owner: -
--

ALTER TABLE support.support_standing_marks ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME support.support_standing_marks_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: attachments; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.attachments (
    id text NOT NULL,
    r2_key text NOT NULL,
    filename text NOT NULL,
    content_type text NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    kind text DEFAULT 'other'::text NOT NULL,
    description text,
    status text DEFAULT 'staged'::text NOT NULL,
    project_id text,
    task_id text,
    note_id text,
    confirmed bigint DEFAULT 0 NOT NULL,
    confirmed_by text,
    confirmed_at text,
    uploaded_by text,
    created_at text NOT NULL,
    updated_at text,
    rowid bigint NOT NULL,
    CONSTRAINT attachments_confirmed_check CHECK ((confirmed = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT attachments_kind_check CHECK ((kind = ANY (ARRAY['image'::text, 'document'::text, 'other'::text]))),
    CONSTRAINT attachments_status_check CHECK ((status = ANY (ARRAY['staged'::text, 'filed'::text])))
);


--
-- Name: attachments_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.attachments ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.attachments_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: audit_log; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.audit_log (
    id text NOT NULL,
    actor_user_id text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    detail text,
    created_at text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: audit_log_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.audit_log ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.audit_log_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bookings; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.bookings (
    id text NOT NULL,
    source text NOT NULL,
    meeting_type text NOT NULL,
    duration_minutes bigint NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    start_utc text NOT NULL,
    end_utc text NOT NULL,
    visitor_timezone text,
    host_timezone text NOT NULL,
    ms_event_id text,
    zoom_meeting_id text,
    zoom_join_url text,
    zoom_waiting_room bigint,
    zoom_auto_recording text,
    status text DEFAULT 'confirmed'::text NOT NULL,
    cancelled_at text,
    cancelled_by_user_id text,
    confirmation_sent_at text,
    reminder_24h_sent_at text,
    reminder_1h_sent_at text,
    created_at text NOT NULL,
    deleted_at text,
    host_id text,
    booked_by text,
    why text,
    host_notice_sent_at text,
    lang text,
    licensed text,
    segment text,
    team_size text,
    agency_flag bigint,
    kind text,
    rowid bigint NOT NULL,
    CONSTRAINT bookings_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT bookings_source_check CHECK ((source = ANY (ARRAY['consulting_intro'::text, 'copilot_demo'::text, 'ricardo_key'::text, 'laura_onboarding'::text, 'ricardo_support'::text]))),
    CONSTRAINT bookings_status_check CHECK ((status = ANY (ARRAY['confirmed'::text, 'cancelled'::text])))
);


--
-- Name: bookings_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.bookings ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.bookings_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: content_items; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.content_items (
    id text NOT NULL,
    brand text NOT NULL,
    batch_id text NOT NULL,
    content_type text NOT NULL,
    language text NOT NULL,
    headline text NOT NULL,
    caption text NOT NULL,
    media_r2_key text NOT NULL,
    thumbnail_r2_key text NOT NULL,
    slide_count bigint DEFAULT 1 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text NOT NULL,
    approved_at text,
    flag_reason text,
    flagged_at text,
    source text DEFAULT 'engine'::text NOT NULL,
    scheduled_at text,
    scheduled_job_id text,
    uploaded_by text,
    rowid bigint NOT NULL,
    CONSTRAINT content_items_brand_check CHECK ((brand = ANY (ARRAY['consulting'::text, 'fitness'::text, 'copilot'::text]))),
    CONSTRAINT content_items_content_type_check CHECK ((content_type = ANY (ARRAY['carousel'::text, 'image'::text, 'video'::text]))),
    CONSTRAINT content_items_language_check CHECK ((language = ANY (ARRAY['en'::text, 'es'::text]))),
    CONSTRAINT content_items_source_check CHECK ((source = ANY (ARRAY['engine'::text, 'upload'::text]))),
    CONSTRAINT content_items_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'approved'::text, 'skipped'::text, 'posted'::text, 'scheduled'::text])))
);


--
-- Name: content_items_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.content_items ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.content_items_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: content_posts; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.content_posts (
    id text NOT NULL,
    content_item_id text NOT NULL,
    provider text NOT NULL,
    brand text NOT NULL,
    profile text,
    platforms text DEFAULT '[]'::text NOT NULL,
    status text NOT NULL,
    response text,
    error text,
    created_at text NOT NULL,
    rowid bigint NOT NULL,
    CONSTRAINT content_posts_status_check CHECK ((status = ANY (ARRAY['posted'::text, 'partial'::text, 'failed'::text])))
);


--
-- Name: content_posts_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.content_posts ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.content_posts_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: events; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.events (
    id text NOT NULL,
    project_id text,
    task_id text,
    event_type text NOT NULL,
    title_en text,
    title_es text,
    calendar_event_link text,
    zoom_meeting_ref text,
    transcript_text text,
    action_items_text text,
    occurred_at text,
    created_at text NOT NULL,
    updated_at text,
    rowid bigint NOT NULL,
    CONSTRAINT events_event_type_check CHECK ((event_type = ANY (ARRAY['calendar'::text, 'zoom_meeting'::text, 'transcript'::text, 'action_item'::text, 'other'::text])))
);


--
-- Name: events_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.events ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.events_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: founder_digest; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.founder_digest (
    id bigint NOT NULL,
    at bigint NOT NULL,
    source text DEFAULT 'unknown'::text NOT NULL,
    bucket text DEFAULT 'observed'::text NOT NULL,
    headline text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    requested_level text DEFAULT 'fyi'::text NOT NULL,
    refused text DEFAULT ''::text NOT NULL,
    sent_at bigint,
    rowid bigint NOT NULL
);


--
-- Name: founder_digest_id_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.founder_digest ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.founder_digest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: founder_digest_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.founder_digest ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.founder_digest_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_approval_cases; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_approval_cases (
    id text NOT NULL,
    case_code text NOT NULL,
    source_system text NOT NULL,
    title text NOT NULL,
    summary text NOT NULL,
    context text,
    risk_class text DEFAULT 'other'::text NOT NULL,
    options_json text,
    status text DEFAULT 'pending'::text NOT NULL,
    decision_text text,
    decision_option text,
    decided_at text,
    external_ref text,
    notified_at text,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT jarvis_approval_cases_risk_class_check CHECK ((risk_class = ANY (ARRAY['money'::text, 'security'::text, 'client_data'::text, 'infrastructure'::text, 'other'::text]))),
    CONSTRAINT jarvis_approval_cases_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'redirected'::text])))
);


--
-- Name: jarvis_approval_cases_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_approval_cases ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_approval_cases_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_conversation; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_conversation (
    id text NOT NULL,
    user_id text,
    role text NOT NULL,
    text text NOT NULL,
    channel text DEFAULT 'dashboard'::text NOT NULL,
    project_id text,
    lang text DEFAULT 'en'::text NOT NULL,
    created_at text NOT NULL,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT jarvis_conversation_channel_check CHECK ((channel = ANY (ARRAY['dashboard'::text, 'telegram'::text]))),
    CONSTRAINT jarvis_conversation_lang_check CHECK ((lang = ANY (ARRAY['en'::text, 'es'::text]))),
    CONSTRAINT jarvis_conversation_role_check CHECK ((role = ANY (ARRAY['user'::text, 'jarvis'::text])))
);


--
-- Name: jarvis_conversation_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_conversation ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_conversation_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_conversation_summary; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_conversation_summary (
    id text NOT NULL,
    user_id text,
    summary text DEFAULT ''::text NOT NULL,
    covers_through text,
    message_count bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text,
    rowid bigint NOT NULL
);


--
-- Name: jarvis_conversation_summary_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_conversation_summary ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_conversation_summary_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_jobs; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_jobs (
    id text NOT NULL,
    user_id text,
    job_type text DEFAULT 'read'::text NOT NULL,
    description text NOT NULL,
    command_json text,
    origin text DEFAULT 'dashboard'::text NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    result_output text,
    result_exit bigint,
    result_error text,
    created_at text NOT NULL,
    approved_at text,
    taken_at text,
    done_at text,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT jarvis_jobs_job_type_check CHECK ((job_type = ANY (ARRAY['read'::text, 'sandbox_write'::text, 'deploy'::text]))),
    CONSTRAINT jarvis_jobs_origin_check CHECK ((origin = ANY (ARRAY['dashboard'::text, 'telegram'::text]))),
    CONSTRAINT jarvis_jobs_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'approved'::text, 'running'::text, 'done'::text, 'error'::text, 'denied'::text])))
);


--
-- Name: jarvis_jobs_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_jobs ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_jobs_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_memories; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_memories (
    id text NOT NULL,
    content text NOT NULL,
    kind text DEFAULT 'fact'::text NOT NULL,
    scope text DEFAULT 'global'::text NOT NULL,
    project_id text,
    source text DEFAULT 'founder'::text NOT NULL,
    confirmed bigint DEFAULT 0 NOT NULL,
    confirmed_by text,
    confirmed_at text,
    is_active bigint DEFAULT 1 NOT NULL,
    created_by text,
    created_at text NOT NULL,
    updated_at text,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT jarvis_memories_check CHECK ((((scope = 'project'::text) AND (NOT (project_id IS NULL))) OR ((scope = 'global'::text) AND (project_id IS NULL)))),
    CONSTRAINT jarvis_memories_confirmed_check CHECK ((confirmed = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT jarvis_memories_is_active_check CHECK ((is_active = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT jarvis_memories_kind_check CHECK ((kind = ANY (ARRAY['decision'::text, 'fact'::text, 'lesson'::text, 'correction'::text, 'preference'::text]))),
    CONSTRAINT jarvis_memories_scope_check CHECK ((scope = ANY (ARRAY['global'::text, 'project'::text])))
);


--
-- Name: jarvis_memories_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_memories ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_memories_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: jarvis_voice_sessions; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.jarvis_voice_sessions (
    id text NOT NULL,
    user_id text,
    status text DEFAULT 'open'::text NOT NULL,
    reserved_usd double precision DEFAULT 0 NOT NULL,
    actual_usd double precision,
    usage_json text,
    end_reason text,
    created_at text NOT NULL,
    ended_at text,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT jarvis_voice_sessions_status_check CHECK ((status = ANY (ARRAY['open'::text, 'closed'::text])))
);


--
-- Name: jarvis_voice_sessions_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.jarvis_voice_sessions ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.jarvis_voice_sessions_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: leads; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.leads (
    id text NOT NULL,
    name text,
    phone text,
    email text,
    source text NOT NULL,
    agency_name text,
    language text DEFAULT 'en'::text NOT NULL,
    stage text DEFAULT 'new'::text NOT NULL,
    notes text,
    next_action text,
    next_action_due text,
    last_touched_at text,
    booking_id text,
    cockpit_ref text,
    external_id text,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text,
    segment text,
    team_size text,
    agency_flag bigint,
    licensed text,
    rowid bigint NOT NULL,
    CONSTRAINT leads_language_check CHECK ((language = ANY (ARRAY['en'::text, 'es'::text]))),
    CONSTRAINT leads_source_check CHECK ((source = ANY (ARRAY['website_access'::text, 'agency_enquiry'::text, 'demo_booking'::text]))),
    CONSTRAINT leads_stage_check CHECK ((stage = ANY (ARRAY['new'::text, 'demo_booked'::text, 'demo_held'::text, 'proposal'::text, 'onboarding'::text, 'active_client'::text, 'lost'::text])))
);


--
-- Name: leads_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.leads ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.leads_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: meeting_summaries; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.meeting_summaries (
    id text NOT NULL,
    source text DEFAULT 'zoom'::text NOT NULL,
    zoom_meeting_id text,
    zoom_uuid text,
    ms_event_id text,
    topic text NOT NULL,
    meeting_start text,
    duration_minutes bigint,
    transcript_r2_key text,
    summary text NOT NULL,
    action_items text DEFAULT '{}'::text NOT NULL,
    model_used text,
    status text DEFAULT 'summarized'::text NOT NULL,
    created_at text NOT NULL,
    lead_id text,
    rowid bigint NOT NULL,
    CONSTRAINT meeting_summaries_source_check CHECK ((source = ANY (ARRAY['zoom'::text, 'notes'::text]))),
    CONSTRAINT meeting_summaries_status_check CHECK ((status = ANY (ARRAY['summarized'::text, 'error'::text])))
);


--
-- Name: meeting_summaries_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.meeting_summaries ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.meeting_summaries_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.notifications (
    id text NOT NULL,
    trigger text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    recipient_user_id text,
    routed_to_role text,
    channel text DEFAULT 'in_app'::text NOT NULL,
    state text DEFAULT 'unread'::text NOT NULL,
    title_en text NOT NULL,
    title_es text,
    body_en text,
    body_es text,
    paste_block text,
    linked_question_id text,
    outbound_message_ref text,
    founder_reply text,
    founder_reply_at text,
    created_at text NOT NULL,
    read_at text,
    actioned_at text,
    rowid bigint NOT NULL,
    CONSTRAINT notifications_channel_check CHECK ((channel = ANY (ARRAY['in_app'::text, 'telegram'::text, 'email'::text]))),
    CONSTRAINT notifications_routed_to_role_check CHECK (((routed_to_role IS NULL) OR (routed_to_role = ANY (ARRAY['admin'::text, 'member'::text, 'developer'::text])))),
    CONSTRAINT notifications_state_check CHECK ((state = ANY (ARRAY['unread'::text, 'read'::text, 'actioned'::text]))),
    CONSTRAINT notifications_trigger_check CHECK ((trigger = ANY (ARRAY['task_completed'::text, 'approval_needed'::text, 'question_routed'::text, 'escalation'::text])))
);


--
-- Name: notifications_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.notifications ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.notifications_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: projects; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.projects (
    id text NOT NULL,
    name_en text NOT NULL,
    name_es text NOT NULL,
    description_en text,
    description_es text,
    status text DEFAULT 'active'::text NOT NULL,
    owner_user_id text NOT NULL,
    created_by text NOT NULL,
    created_at text NOT NULL,
    updated_at text,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT projects_status_check CHECK ((status = ANY (ARRAY['active'::text, 'on_hold'::text, 'complete'::text, 'archived'::text])))
);


--
-- Name: projects_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.projects ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.projects_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: questions; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.questions (
    id text NOT NULL,
    task_id text,
    sub_chat_id text,
    asked_by_user_id text,
    question_en text NOT NULL,
    question_es text,
    route_to text DEFAULT 'owner'::text NOT NULL,
    owner_user_id text,
    answered_by text,
    answer_en text,
    answer_es text,
    status text DEFAULT 'open'::text NOT NULL,
    created_at text NOT NULL,
    answered_at text,
    rowid bigint NOT NULL,
    CONSTRAINT questions_answered_by_check CHECK (((answered_by IS NULL) OR (answered_by = ANY (ARRAY['jarvis_auto'::text, 'human'::text])))),
    CONSTRAINT questions_route_to_check CHECK ((route_to = ANY (ARRAY['owner'::text, 'founder'::text]))),
    CONSTRAINT questions_status_check CHECK ((status = ANY (ARRAY['open'::text, 'answered'::text, 'escalated'::text])))
);


--
-- Name: questions_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.questions ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.questions_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resources; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.resources (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_name text NOT NULL,
    access_mode text DEFAULT 'write'::text NOT NULL,
    task_id text,
    sub_chat_id text,
    created_at text NOT NULL,
    rowid bigint NOT NULL,
    CONSTRAINT resources_access_mode_check CHECK ((access_mode = ANY (ARRAY['read'::text, 'write'::text]))),
    CONSTRAINT resources_check CHECK (((NOT (task_id IS NULL)) OR (NOT (sub_chat_id IS NULL)))),
    CONSTRAINT resources_resource_type_check CHECK ((resource_type = ANY (ARRAY['file'::text, 'repo'::text, 'branch'::text, 'deployed_resource'::text])))
);


--
-- Name: resources_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.resources ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.resources_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: settings; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.settings (
    id text NOT NULL,
    key text NOT NULL,
    value text,
    value_type text DEFAULT 'string'::text NOT NULL,
    description_en text,
    description_es text,
    updated_by text,
    updated_at text,
    rowid bigint NOT NULL,
    CONSTRAINT settings_value_type_check CHECK ((value_type = ANY (ARRAY['string'::text, 'number'::text, 'boolean'::text, 'json'::text])))
);


--
-- Name: settings_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.settings ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.settings_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sub_chats; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.sub_chats (
    id text NOT NULL,
    name_en text NOT NULL,
    name_es text NOT NULL,
    project_id text NOT NULL,
    task_id text,
    model text NOT NULL,
    status text DEFAULT 'not_started'::text NOT NULL,
    percent_complete bigint DEFAULT 0 NOT NULL,
    color text,
    last_status_note text,
    last_reported_at text,
    created_at text NOT NULL,
    updated_at text,
    rowid bigint NOT NULL,
    CONSTRAINT sub_chats_percent_complete_check CHECK (((percent_complete >= 0) AND (percent_complete <= 100))),
    CONSTRAINT sub_chats_status_check CHECK ((status = ANY (ARRAY['not_started'::text, 'in_progress'::text, 'running'::text, 'requires_attention'::text, 'on_hold'::text, 'blocked'::text, 'done'::text])))
);


--
-- Name: sub_chats_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.sub_chats ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.sub_chats_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_dependencies; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.task_dependencies (
    id text NOT NULL,
    task_id text NOT NULL,
    depends_on_task_id text NOT NULL,
    created_at text NOT NULL,
    rowid bigint NOT NULL
);


--
-- Name: task_dependencies_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.task_dependencies ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.task_dependencies_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_notes; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.task_notes (
    id text NOT NULL,
    task_id text NOT NULL,
    author_user_id text NOT NULL,
    body text NOT NULL,
    created_at text NOT NULL,
    deleted_at text,
    rowid bigint NOT NULL
);


--
-- Name: task_notes_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.task_notes ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.task_notes_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tasks; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.tasks (
    id text NOT NULL,
    project_id text NOT NULL,
    title_en text NOT NULL,
    title_es text NOT NULL,
    description_en text,
    description_es text,
    status text DEFAULT 'not_started'::text NOT NULL,
    percent_complete bigint DEFAULT 0 NOT NULL,
    assignee_user_id text,
    assignment_mode text DEFAULT 'unassigned'::text NOT NULL,
    estimated_minutes bigint,
    actual_minutes bigint,
    approve_before_done bigint DEFAULT 0 NOT NULL,
    automate_or_human text DEFAULT 'human'::text NOT NULL,
    is_sensitive_client_data bigint DEFAULT 0 NOT NULL,
    source_event_id text,
    completed_by_user_id text,
    completed_at text,
    approved_by_user_id text,
    approved_at text,
    created_by text NOT NULL,
    created_at text NOT NULL,
    updated_at text,
    deleted_at text,
    rowid bigint NOT NULL,
    CONSTRAINT tasks_approve_before_done_check CHECK ((approve_before_done = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT tasks_assignment_mode_check CHECK ((assignment_mode = ANY (ARRAY['unassigned'::text, 'assigned'::text, 'claimed'::text]))),
    CONSTRAINT tasks_automate_or_human_check CHECK ((automate_or_human = ANY (ARRAY['automate'::text, 'human'::text]))),
    CONSTRAINT tasks_is_sensitive_client_data_check CHECK ((is_sensitive_client_data = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT tasks_percent_complete_check CHECK (((percent_complete >= 0) AND (percent_complete <= 100))),
    CONSTRAINT tasks_status_check CHECK ((status = ANY (ARRAY['not_started'::text, 'in_progress'::text, 'blocked'::text, 'on_hold'::text, 'requires_attention'::text, 'awaiting_approval'::text, 'done'::text])))
);


--
-- Name: tasks_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.tasks ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.tasks_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: teamops; Owner: -
--

CREATE TABLE teamops.users (
    id text NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    preferred_language text DEFAULT 'en'::text NOT NULL,
    is_active bigint DEFAULT 1 NOT NULL,
    created_at text NOT NULL,
    updated_at text,
    photo_key text,
    photo_content_type text,
    photo_updated_at text,
    content_only bigint DEFAULT 0 NOT NULL,
    rowid bigint NOT NULL,
    CONSTRAINT users_content_only_check CHECK ((content_only = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT users_is_active_check CHECK ((is_active = ANY (ARRAY[(0)::bigint, (1)::bigint]))),
    CONSTRAINT users_preferred_language_check CHECK ((preferred_language = ANY (ARRAY['en'::text, 'es'::text]))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text, 'developer'::text])))
);


--
-- Name: users_rowid_seq; Type: SEQUENCE; Schema: teamops; Owner: -
--

ALTER TABLE teamops.users ALTER COLUMN rowid ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME teamops.users_rowid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: session_events; Type: TABLE; Schema: viewer; Owner: -
--

CREATE TABLE viewer.session_events (
    id text NOT NULL,
    session_id text NOT NULL,
    event_type text NOT NULL,
    card_type text,
    payload_json text,
    agent_id text DEFAULT ''::text NOT NULL,
    call_id text,
    ts text NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: viewer; Owner: -
--

CREATE TABLE viewer.sessions (
    id text NOT NULL,
    agent_id text DEFAULT ''::text NOT NULL,
    client_label text DEFAULT ''::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    token_hash text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    current_card_json text,
    card_seq bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    expires_at text NOT NULL,
    ended_at text,
    annotations_json text,
    agent_name text DEFAULT ''::text NOT NULL,
    agent_npn text DEFAULT ''::text NOT NULL,
    agent_photo text DEFAULT ''::text NOT NULL,
    CONSTRAINT sessions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'ended'::text, 'expired'::text])))
);


--
-- PostgreSQL database dump complete
--

