--
-- PostgreSQL database dump
--

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (account_id);


--
-- Name: calls calls_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.calls
    ADD CONSTRAINT calls_pkey PRIMARY KEY (attempt_id);


--
-- Name: collector_runs collector_runs_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.collector_runs
    ADD CONSTRAINT collector_runs_pkey PRIMARY KEY (run_id);


--
-- Name: day_rollup day_rollup_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.day_rollup
    ADD CONSTRAINT day_rollup_pkey PRIMARY KEY (day_et, scope, scope_key);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (quote_id);


--
-- Name: revenue_accounts revenue_accounts_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.revenue_accounts
    ADD CONSTRAINT revenue_accounts_pkey PRIMARY KEY (account_id);


--
-- Name: revenue_meta revenue_meta_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.revenue_meta
    ADD CONSTRAINT revenue_meta_pkey PRIMARY KEY (id);


--
-- Name: watermark watermark_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.watermark
    ADD CONSTRAINT watermark_pkey PRIMARY KEY (id);


--
-- Name: acts acts_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.acts
    ADD CONSTRAINT acts_pkey PRIMARY KEY (id);


--
-- Name: costs costs_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.costs
    ADD CONSTRAINT costs_pkey PRIMARY KEY (id);


--
-- Name: filed_words filed_words_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.filed_words
    ADD CONSTRAINT filed_words_pkey PRIMARY KEY (hash);


--
-- Name: heard heard_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.heard
    ADD CONSTRAINT heard_pkey PRIMARY KEY (hash, user_id);


--
-- Name: held held_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.held
    ADD CONSTRAINT held_pkey PRIMARY KEY (key);


--
-- Name: processed processed_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.processed
    ADD CONSTRAINT processed_pkey PRIMARY KEY (report_id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.threads
    ADD CONSTRAINT threads_pkey PRIMARY KEY (key);


--
-- Name: turns turns_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.turns
    ADD CONSTRAINT turns_pkey PRIMARY KEY (id);


--
-- Name: words words_pkey; Type: CONSTRAINT; Schema: autofix; Owner: -
--

ALTER TABLE ONLY autofix.words
    ADD CONSTRAINT words_pkey PRIMARY KEY (code);


--
-- Name: script_master_before_cleanup_20261015 script_master_before_cleanup_20261015_pkey; Type: CONSTRAINT; Schema: aws_validation; Owner: -
--

ALTER TABLE ONLY aws_validation.script_master_before_cleanup_20261015
    ADD CONSTRAINT script_master_before_cleanup_20261015_pkey PRIMARY KEY (id);


--
-- Name: care_automation_rules care_automation_rules_pkey; Type: CONSTRAINT; Schema: gifts; Owner: -
--

ALTER TABLE ONLY gifts.care_automation_rules
    ADD CONSTRAINT care_automation_rules_pkey PRIMARY KEY (id);


--
-- Name: care_billing_profiles care_billing_profiles_pkey; Type: CONSTRAINT; Schema: gifts; Owner: -
--

ALTER TABLE ONLY gifts.care_billing_profiles
    ADD CONSTRAINT care_billing_profiles_pkey PRIMARY KEY (agent_account_id);


--
-- Name: care_events care_events_pkey; Type: CONSTRAINT; Schema: gifts; Owner: -
--

ALTER TABLE ONLY gifts.care_events
    ADD CONSTRAINT care_events_pkey PRIMARY KEY (id);


--
-- Name: care_opportunities care_opportunities_pkey; Type: CONSTRAINT; Schema: gifts; Owner: -
--

ALTER TABLE ONLY gifts.care_opportunities
    ADD CONSTRAINT care_opportunities_pkey PRIMARY KEY (id);


--
-- Name: care_orders care_orders_pkey; Type: CONSTRAINT; Schema: gifts; Owner: -
--

ALTER TABLE ONLY gifts.care_orders
    ADD CONSTRAINT care_orders_pkey PRIMARY KEY (id);


--
-- Name: approved_faq approved_faq_pkey; Type: CONSTRAINT; Schema: help; Owner: -
--

ALTER TABLE ONLY help.approved_faq
    ADD CONSTRAINT approved_faq_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: help; Owner: -
--

ALTER TABLE ONLY help.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: card_prefs card_prefs_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.card_prefs
    ADD CONSTRAINT card_prefs_pkey PRIMARY KEY (slug);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: privacy_requests privacy_requests_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.privacy_requests
    ADD CONSTRAINT privacy_requests_pkey PRIMARY KEY (id);


--
-- Name: producers producers_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.producers
    ADD CONSTRAINT producers_pkey PRIMARY KEY (slug);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: waitlist waitlist_email_key; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.waitlist
    ADD CONSTRAINT waitlist_email_key UNIQUE (email);


--
-- Name: waitlist waitlist_pkey; Type: CONSTRAINT; Schema: marketplace; Owner: -
--

ALTER TABLE ONLY marketplace.waitlist
    ADD CONSTRAINT waitlist_pkey PRIMARY KEY (id);


--
-- Name: acc_appeals acc_appeals_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_appeals
    ADD CONSTRAINT acc_appeals_pkey PRIMARY KEY (id);


--
-- Name: acc_entries acc_entries_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_entries
    ADD CONSTRAINT acc_entries_pkey PRIMARY KEY (id);


--
-- Name: acc_events acc_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_events
    ADD CONSTRAINT acc_events_pkey PRIMARY KEY (id);


--
-- Name: acc_matters acc_matters_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_matters
    ADD CONSTRAINT acc_matters_pkey PRIMARY KEY (id);


--
-- Name: acc_notices acc_notices_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_notices
    ADD CONSTRAINT acc_notices_pkey PRIMARY KEY (id);


--
-- Name: acc_notices acc_notices_rowid_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_notices
    ADD CONSTRAINT acc_notices_rowid_key UNIQUE (rowid);


--
-- Name: acc_records_requests acc_records_requests_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_records_requests
    ADD CONSTRAINT acc_records_requests_pkey PRIMARY KEY (id);


--
-- Name: acc_review_disputes acc_review_disputes_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_review_disputes
    ADD CONSTRAINT acc_review_disputes_pkey PRIMARY KEY (id);


--
-- Name: acc_role_designations acc_role_designations_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_role_designations
    ADD CONSTRAINT acc_role_designations_pkey PRIMARY KEY (id);


--
-- Name: acc_role_designations acc_role_designations_rowid_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_role_designations
    ADD CONSTRAINT acc_role_designations_rowid_key UNIQUE (rowid);


--
-- Name: accounts accounts_email_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.accounts
    ADD CONSTRAINT accounts_email_key UNIQUE (email);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: additional_agents additional_agents_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.additional_agents
    ADD CONSTRAINT additional_agents_pkey PRIMARY KEY (id);


--
-- Name: agencies agencies_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agencies
    ADD CONSTRAINT agencies_pkey PRIMARY KEY (id);


--
-- Name: agency_team_leads agency_team_leads_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agency_team_leads
    ADD CONSTRAINT agency_team_leads_pkey PRIMARY KEY (agency_id, leader_account_id, member_account_id);


--
-- Name: agent_document_signatures agent_document_signatures_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_document_signatures
    ADD CONSTRAINT agent_document_signatures_pkey PRIMARY KEY (id);


--
-- Name: agent_phone_numbers agent_phone_numbers_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_phone_numbers
    ADD CONSTRAINT agent_phone_numbers_pkey PRIMARY KEY (account_id, e164);


--
-- Name: agent_phone_numbers agent_phone_numbers_rowid_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_phone_numbers
    ADD CONSTRAINT agent_phone_numbers_rowid_key UNIQUE (rowid);


--
-- Name: agent_signature_resets agent_signature_resets_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_signature_resets
    ADD CONSTRAINT agent_signature_resets_pkey PRIMARY KEY (id);


--
-- Name: agent_webrtc_credentials agent_webrtc_credentials_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_webrtc_credentials
    ADD CONSTRAINT agent_webrtc_credentials_pkey PRIMARY KEY (id);


--
-- Name: agreements agreements_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agreements
    ADD CONSTRAINT agreements_pkey PRIMARY KEY (id);


--
-- Name: application_snapshots application_snapshots_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.application_snapshots
    ADD CONSTRAINT application_snapshots_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_log auth_audit_log_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.auth_audit_log
    ADD CONSTRAINT auth_audit_log_pkey PRIMARY KEY (id);


--
-- Name: call_coaching call_coaching_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.call_coaching
    ADD CONSTRAINT call_coaching_pkey PRIMARY KEY (call_id);


--
-- Name: call_transcripts call_transcripts_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.call_transcripts
    ADD CONSTRAINT call_transcripts_pkey PRIMARY KEY (call_id);


--
-- Name: client_acknowledgments client_acknowledgments_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.client_acknowledgments
    ADD CONSTRAINT client_acknowledgments_pkey PRIMARY KEY (id);


--
-- Name: coaching_jobs coaching_jobs_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.coaching_jobs
    ADD CONSTRAINT coaching_jobs_pkey PRIMARY KEY (call_id);


--
-- Name: coaching_rollups coaching_rollups_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.coaching_rollups
    ADD CONSTRAINT coaching_rollups_pkey PRIMARY KEY (agent_account_id, period_type, period_key);


--
-- Name: compliance_detections compliance_detections_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.compliance_detections
    ADD CONSTRAINT compliance_detections_pkey PRIMARY KEY (id);


--
-- Name: crm_presence crm_presence_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.crm_presence
    ADD CONSTRAINT crm_presence_pkey PRIMARY KEY (account_id);


--
-- Name: disclosure_evidence disclosure_evidence_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.disclosure_evidence
    ADD CONSTRAINT disclosure_evidence_pkey PRIMARY KEY (id);


--
-- Name: disclosure_purges disclosure_purges_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.disclosure_purges
    ADD CONSTRAINT disclosure_purges_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_log email_log_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.email_log
    ADD CONSTRAINT email_log_pkey PRIMARY KEY (id);


--
-- Name: envelope_events envelope_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_events
    ADD CONSTRAINT envelope_events_pkey PRIMARY KEY (id);


--
-- Name: envelope_events envelope_events_rowid_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_events
    ADD CONSTRAINT envelope_events_rowid_key UNIQUE (rowid);


--
-- Name: envelope_otp envelope_otp_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_otp
    ADD CONSTRAINT envelope_otp_pkey PRIMARY KEY (id);


--
-- Name: envelope_otp envelope_otp_rowid_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_otp
    ADD CONSTRAINT envelope_otp_rowid_key UNIQUE (rowid);


--
-- Name: envelopes envelopes_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelopes
    ADD CONSTRAINT envelopes_pkey PRIMARY KEY (id);


--
-- Name: eo_status eo_status_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.eo_status
    ADD CONSTRAINT eo_status_pkey PRIMARY KEY (account_id);


--
-- Name: evidence_audit_log evidence_audit_log_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.evidence_audit_log
    ADD CONSTRAINT evidence_audit_log_pkey PRIMARY KEY (id);


--
-- Name: headshot_finishes headshot_finishes_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.headshot_finishes
    ADD CONSTRAINT headshot_finishes_pkey PRIMARY KEY (id);


--
-- Name: headshot_jobs headshot_jobs_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.headshot_jobs
    ADD CONSTRAINT headshot_jobs_pkey PRIMARY KEY (id);


--
-- Name: headshot_rejections headshot_rejections_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.headshot_rejections
    ADD CONSTRAINT headshot_rejections_pkey PRIMARY KEY (sha256);


--
-- Name: headshot_spend_notices headshot_spend_notices_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.headshot_spend_notices
    ADD CONSTRAINT headshot_spend_notices_pkey PRIMARY KEY (month);


--
-- Name: headshot_spend headshot_spend_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.headshot_spend
    ADD CONSTRAINT headshot_spend_pkey PRIMARY KEY (id);


--
-- Name: impersonation_actions impersonation_actions_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.impersonation_actions
    ADD CONSTRAINT impersonation_actions_pkey PRIMARY KEY (id);


--
-- Name: lead_alert_held_rings lead_alert_held_rings_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_held_rings
    ADD CONSTRAINT lead_alert_held_rings_pkey PRIMARY KEY (id);


--
-- Name: lead_alert_optins lead_alert_optins_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_optins
    ADD CONSTRAINT lead_alert_optins_pkey PRIMARY KEY (account_id);


--
-- Name: lead_alert_probes lead_alert_probes_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_probes
    ADD CONSTRAINT lead_alert_probes_pkey PRIMARY KEY (id);


--
-- Name: lead_alert_recipients lead_alert_recipients_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_recipients
    ADD CONSTRAINT lead_alert_recipients_pkey PRIMARY KEY (id);


--
-- Name: lead_alert_rings lead_alert_rings_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_rings
    ADD CONSTRAINT lead_alert_rings_pkey PRIMARY KEY (id);


--
-- Name: lead_views lead_views_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_views
    ADD CONSTRAINT lead_views_pkey PRIMARY KEY (id);


--
-- Name: leads leads_email_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.leads
    ADD CONSTRAINT leads_email_key UNIQUE (email);


--
-- Name: leads_interest leads_interest_email_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.leads_interest
    ADD CONSTRAINT leads_interest_email_key UNIQUE (email);


--
-- Name: leads_interest leads_interest_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.leads_interest
    ADD CONSTRAINT leads_interest_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: license_confirmations license_confirmations_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_confirmations
    ADD CONSTRAINT license_confirmations_pkey PRIMARY KEY (account_id, state);


--
-- Name: license_status license_status_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_status
    ADD CONSTRAINT license_status_pkey PRIMARY KEY (account_id, state);


--
-- Name: license_sweep_state license_sweep_state_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_sweep_state
    ADD CONSTRAINT license_sweep_state_pkey PRIMARY KEY (id);


--
-- Name: license_withdrawals license_withdrawals_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_withdrawals
    ADD CONSTRAINT license_withdrawals_pkey PRIMARY KEY (account_id, state);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: login_events login_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.login_events
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: money_events money_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.money_events
    ADD CONSTRAINT money_events_pkey PRIMARY KEY (id);


--
-- Name: number_accrual_state number_accrual_state_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_accrual_state
    ADD CONSTRAINT number_accrual_state_pkey PRIMARY KEY (id);


--
-- Name: number_events number_events_dedupe_key_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_events
    ADD CONSTRAINT number_events_dedupe_key_key UNIQUE (dedupe_key);


--
-- Name: number_events number_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_events
    ADD CONSTRAINT number_events_pkey PRIMARY KEY (id);


--
-- Name: number_registrations number_registrations_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_registrations
    ADD CONSTRAINT number_registrations_pkey PRIMARY KEY (e164, program);


--
-- Name: number_releases number_releases_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_releases
    ADD CONSTRAINT number_releases_pkey PRIMARY KEY (account_id, e164);


--
-- Name: number_requests number_requests_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_requests
    ADD CONSTRAINT number_requests_pkey PRIMARY KEY (account_id, state);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: platform_waitlist platform_waitlist_email_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.platform_waitlist
    ADD CONSTRAINT platform_waitlist_email_key UNIQUE (email);


--
-- Name: platform_waitlist platform_waitlist_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.platform_waitlist
    ADD CONSTRAINT platform_waitlist_pkey PRIMARY KEY (id);


--
-- Name: pool_line_requests pool_line_requests_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.pool_line_requests
    ADD CONSTRAINT pool_line_requests_pkey PRIMARY KEY (id);


--
-- Name: privacy_requests privacy_requests_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.privacy_requests
    ADD CONSTRAINT privacy_requests_pkey PRIMARY KEY (id);


--
-- Name: producer_documents producer_documents_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_documents
    ADD CONSTRAINT producer_documents_pkey PRIMARY KEY (id);


--
-- Name: producer_licenses producer_licenses_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_licenses
    ADD CONSTRAINT producer_licenses_pkey PRIMARY KEY (producer_slug, state);


--
-- Name: producer_seeds producer_seeds_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_seeds
    ADD CONSTRAINT producer_seeds_pkey PRIMARY KEY (account_id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (account_id);


--
-- Name: rotation_line_requests rotation_line_requests_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.rotation_line_requests
    ADD CONSTRAINT rotation_line_requests_pkey PRIMARY KEY (account_id, state, slot);


--
-- Name: script_master script_master_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.script_master
    ADD CONSTRAINT script_master_pkey PRIMARY KEY (id);


--
-- Name: seat_offboard_notices seat_offboard_notices_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_offboard_notices
    ADD CONSTRAINT seat_offboard_notices_pkey PRIMARY KEY (account_id, notice);


--
-- Name: seat_offboard_schedule seat_offboard_schedule_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_offboard_schedule
    ADD CONSTRAINT seat_offboard_schedule_pkey PRIMARY KEY (account_id);


--
-- Name: seat_offboard_sweep_state seat_offboard_sweep_state_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_offboard_sweep_state
    ADD CONSTRAINT seat_offboard_sweep_state_pkey PRIMARY KEY (id);


--
-- Name: seat_trial_notices seat_trial_notices_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_trial_notices
    ADD CONSTRAINT seat_trial_notices_pkey PRIMARY KEY (account_id, notice);


--
-- Name: seat_trial_sweep_state seat_trial_sweep_state_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_trial_sweep_state
    ADD CONSTRAINT seat_trial_sweep_state_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: signdesk_routes signdesk_routes_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.signdesk_routes
    ADD CONSTRAINT signdesk_routes_pkey PRIMARY KEY (id);


--
-- Name: signdesk_templates signdesk_templates_name_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.signdesk_templates
    ADD CONSTRAINT signdesk_templates_name_key UNIQUE (name);


--
-- Name: signdesk_templates signdesk_templates_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.signdesk_templates
    ADD CONSTRAINT signdesk_templates_pkey PRIMARY KEY (id);


--
-- Name: signing_handoffs signing_handoffs_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.signing_handoffs
    ADD CONSTRAINT signing_handoffs_pkey PRIMARY KEY (id);


--
-- Name: unipile_connections unipile_connections_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.unipile_connections
    ADD CONSTRAINT unipile_connections_pkey PRIMARY KEY (account_id);


--
-- Name: usage_events usage_events_idempotency_key_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.usage_events
    ADD CONSTRAINT usage_events_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: usage_events usage_events_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.usage_events
    ADD CONSTRAINT usage_events_pkey PRIMARY KEY (id);


--
-- Name: usage_report_runs usage_report_runs_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.usage_report_runs
    ADD CONSTRAINT usage_report_runs_pkey PRIMARY KEY (id);


--
-- Name: vcard_chat_usage vcard_chat_usage_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.vcard_chat_usage
    ADD CONSTRAINT vcard_chat_usage_pkey PRIMARY KEY (bucket);


--
-- Name: vcard_interest vcard_interest_email_key; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.vcard_interest
    ADD CONSTRAINT vcard_interest_email_key UNIQUE (email);


--
-- Name: vcard_interest vcard_interest_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.vcard_interest
    ADD CONSTRAINT vcard_interest_pkey PRIMARY KEY (id);


--
-- Name: vip_producers vip_producers_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.vip_producers
    ADD CONSTRAINT vip_producers_pkey PRIMARY KEY (slug);


--
-- Name: vsl_verification vsl_verification_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.vsl_verification
    ADD CONSTRAINT vsl_verification_pkey PRIMARY KEY (email);


--
-- Name: welcome_sends welcome_sends_pkey; Type: CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.welcome_sends
    ADD CONSTRAINT welcome_sends_pkey PRIMARY KEY (account_id);


--
-- Name: aws_adapter_probe aws_adapter_probe_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aws_adapter_probe
    ADD CONSTRAINT aws_adapter_probe_pkey PRIMARY KEY (id);


--
-- Name: pbg_asset_jobs pbg_asset_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_asset_jobs
    ADD CONSTRAINT pbg_asset_jobs_pkey PRIMARY KEY (id);


--
-- Name: pbg_aws_migrations pbg_aws_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_aws_migrations
    ADD CONSTRAINT pbg_aws_migrations_pkey PRIMARY KEY (name);


--
-- Name: pbg_corporate_sessions pbg_corporate_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_corporate_sessions
    ADD CONSTRAINT pbg_corporate_sessions_pkey PRIMARY KEY (key);


--
-- Name: pbg_import_originals pbg_import_originals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_import_originals
    ADD CONSTRAINT pbg_import_originals_pkey PRIMARY KEY (schema_name, table_name, source_rowid, column_name);


--
-- Name: pbg_phone_proof pbg_phone_proof_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_phone_proof
    ADD CONSTRAINT pbg_phone_proof_pkey PRIMARY KEY (owner, kind, id);


--
-- Name: pbg_published_assets pbg_published_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_published_assets
    ADD CONSTRAINT pbg_published_assets_pkey PRIMARY KEY (surface, path);


--
-- Name: pbg_room_alarms pbg_room_alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_room_alarms
    ADD CONSTRAINT pbg_room_alarms_pkey PRIMARY KEY (room);


--
-- Name: pbg_room_state pbg_room_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_room_state
    ADD CONSTRAINT pbg_room_state_pkey PRIMARY KEY (room, key);


--
-- Name: pbg_state_appends pbg_state_appends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_state_appends
    ADD CONSTRAINT pbg_state_appends_pkey PRIMARY KEY (sequence);


--
-- Name: pbg_state_documents pbg_state_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_state_documents
    ADD CONSTRAINT pbg_state_documents_pkey PRIMARY KEY (path);


--
-- Name: pbg_state_media pbg_state_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_state_media
    ADD CONSTRAINT pbg_state_media_pkey PRIMARY KEY (path);


--
-- Name: pbg_validation_events pbg_validation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_validation_events
    ADD CONSTRAINT pbg_validation_events_pkey PRIMARY KEY (id);


--
-- Name: agent_meeting_items agent_meeting_items_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meeting_items
    ADD CONSTRAINT agent_meeting_items_pkey PRIMARY KEY (id);


--
-- Name: agent_meeting_items agent_meeting_items_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meeting_items
    ADD CONSTRAINT agent_meeting_items_rowid_key UNIQUE (rowid);


--
-- Name: agent_meeting_transcripts agent_meeting_transcripts_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meeting_transcripts
    ADD CONSTRAINT agent_meeting_transcripts_pkey PRIMARY KEY (meeting_id);


--
-- Name: agent_meeting_transcripts agent_meeting_transcripts_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meeting_transcripts
    ADD CONSTRAINT agent_meeting_transcripts_rowid_key UNIQUE (rowid);


--
-- Name: agent_meetings agent_meetings_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meetings
    ADD CONSTRAINT agent_meetings_pkey PRIMARY KEY (id);


--
-- Name: agent_meetings agent_meetings_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.agent_meetings
    ADD CONSTRAINT agent_meetings_rowid_key UNIQUE (rowid);


--
-- Name: support_actions support_actions_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_actions
    ADD CONSTRAINT support_actions_pkey PRIMARY KEY (id);


--
-- Name: support_actions support_actions_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_actions
    ADD CONSTRAINT support_actions_rowid_key UNIQUE (rowid);


--
-- Name: support_activation_docs support_activation_docs_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activation_docs
    ADD CONSTRAINT support_activation_docs_pkey PRIMARY KEY (id);


--
-- Name: support_activation_docs support_activation_docs_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activation_docs
    ADD CONSTRAINT support_activation_docs_rowid_key UNIQUE (rowid);


--
-- Name: support_activation_steps support_activation_steps_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activation_steps
    ADD CONSTRAINT support_activation_steps_pkey PRIMARY KEY (id);


--
-- Name: support_activation_steps support_activation_steps_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activation_steps
    ADD CONSTRAINT support_activation_steps_rowid_key UNIQUE (rowid);


--
-- Name: support_activations support_activations_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activations
    ADD CONSTRAINT support_activations_pkey PRIMARY KEY (id);


--
-- Name: support_activations support_activations_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_activations
    ADD CONSTRAINT support_activations_rowid_key UNIQUE (rowid);


--
-- Name: support_approvals support_approvals_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_approvals
    ADD CONSTRAINT support_approvals_pkey PRIMARY KEY (id);


--
-- Name: support_approvals support_approvals_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_approvals
    ADD CONSTRAINT support_approvals_rowid_key UNIQUE (rowid);


--
-- Name: support_cases support_cases_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_cases
    ADD CONSTRAINT support_cases_pkey PRIMARY KEY (id);


--
-- Name: support_cases support_cases_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_cases
    ADD CONSTRAINT support_cases_rowid_key UNIQUE (rowid);


--
-- Name: support_issues support_issues_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_issues
    ADD CONSTRAINT support_issues_pkey PRIMARY KEY (id);


--
-- Name: support_issues support_issues_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_issues
    ADD CONSTRAINT support_issues_rowid_key UNIQUE (rowid);


--
-- Name: support_jarvis_costs support_jarvis_costs_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_costs
    ADD CONSTRAINT support_jarvis_costs_pkey PRIMARY KEY (id);


--
-- Name: support_jarvis_costs support_jarvis_costs_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_costs
    ADD CONSTRAINT support_jarvis_costs_rowid_key UNIQUE (rowid);


--
-- Name: support_jarvis_threads support_jarvis_threads_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_threads
    ADD CONSTRAINT support_jarvis_threads_pkey PRIMARY KEY (id);


--
-- Name: support_jarvis_threads support_jarvis_threads_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_threads
    ADD CONSTRAINT support_jarvis_threads_rowid_key UNIQUE (rowid);


--
-- Name: support_jarvis_turns support_jarvis_turns_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_turns
    ADD CONSTRAINT support_jarvis_turns_pkey PRIMARY KEY (id);


--
-- Name: support_jarvis_turns support_jarvis_turns_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_jarvis_turns
    ADD CONSTRAINT support_jarvis_turns_rowid_key UNIQUE (rowid);


--
-- Name: support_mail_log support_mail_log_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_mail_log
    ADD CONSTRAINT support_mail_log_pkey PRIMARY KEY (id);


--
-- Name: support_mail_log support_mail_log_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_mail_log
    ADD CONSTRAINT support_mail_log_rowid_key UNIQUE (rowid);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_messages
    ADD CONSTRAINT support_messages_rowid_key UNIQUE (rowid);


--
-- Name: support_notes support_notes_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_notes
    ADD CONSTRAINT support_notes_pkey PRIMARY KEY (id);


--
-- Name: support_notes support_notes_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_notes
    ADD CONSTRAINT support_notes_rowid_key UNIQUE (rowid);


--
-- Name: support_operator_events support_operator_events_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_operator_events
    ADD CONSTRAINT support_operator_events_pkey PRIMARY KEY (id);


--
-- Name: support_operator_events support_operator_events_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_operator_events
    ADD CONSTRAINT support_operator_events_rowid_key UNIQUE (rowid);


--
-- Name: support_operators support_operators_email_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_operators
    ADD CONSTRAINT support_operators_email_key UNIQUE (email);


--
-- Name: support_operators support_operators_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_operators
    ADD CONSTRAINT support_operators_pkey PRIMARY KEY (id);


--
-- Name: support_operators support_operators_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_operators
    ADD CONSTRAINT support_operators_rowid_key UNIQUE (rowid);


--
-- Name: support_ops_requests support_ops_requests_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_ops_requests
    ADD CONSTRAINT support_ops_requests_pkey PRIMARY KEY (id);


--
-- Name: support_ops_requests support_ops_requests_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_ops_requests
    ADD CONSTRAINT support_ops_requests_rowid_key UNIQUE (rowid);


--
-- Name: support_recipes support_recipes_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_recipes
    ADD CONSTRAINT support_recipes_pkey PRIMARY KEY (id);


--
-- Name: support_recipes support_recipes_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_recipes
    ADD CONSTRAINT support_recipes_rowid_key UNIQUE (rowid);


--
-- Name: support_recipes support_recipes_slug_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_recipes
    ADD CONSTRAINT support_recipes_slug_key UNIQUE (slug);


--
-- Name: support_standing_marks support_standing_marks_pkey; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_standing_marks
    ADD CONSTRAINT support_standing_marks_pkey PRIMARY KEY (id);


--
-- Name: support_standing_marks support_standing_marks_rowid_key; Type: CONSTRAINT; Schema: support; Owner: -
--

ALTER TABLE ONLY support.support_standing_marks
    ADD CONSTRAINT support_standing_marks_rowid_key UNIQUE (rowid);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_rowid_key UNIQUE (rowid);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.audit_log
    ADD CONSTRAINT audit_log_rowid_key UNIQUE (rowid);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.bookings
    ADD CONSTRAINT bookings_rowid_key UNIQUE (rowid);


--
-- Name: content_items content_items_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.content_items
    ADD CONSTRAINT content_items_pkey PRIMARY KEY (id);


--
-- Name: content_items content_items_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.content_items
    ADD CONSTRAINT content_items_rowid_key UNIQUE (rowid);


--
-- Name: content_posts content_posts_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.content_posts
    ADD CONSTRAINT content_posts_pkey PRIMARY KEY (id);


--
-- Name: content_posts content_posts_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.content_posts
    ADD CONSTRAINT content_posts_rowid_key UNIQUE (rowid);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: events events_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.events
    ADD CONSTRAINT events_rowid_key UNIQUE (rowid);


--
-- Name: founder_digest founder_digest_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.founder_digest
    ADD CONSTRAINT founder_digest_pkey PRIMARY KEY (id);


--
-- Name: founder_digest founder_digest_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.founder_digest
    ADD CONSTRAINT founder_digest_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_approval_cases jarvis_approval_cases_case_code_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_approval_cases
    ADD CONSTRAINT jarvis_approval_cases_case_code_key UNIQUE (case_code);


--
-- Name: jarvis_approval_cases jarvis_approval_cases_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_approval_cases
    ADD CONSTRAINT jarvis_approval_cases_pkey PRIMARY KEY (id);


--
-- Name: jarvis_approval_cases jarvis_approval_cases_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_approval_cases
    ADD CONSTRAINT jarvis_approval_cases_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_conversation jarvis_conversation_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation
    ADD CONSTRAINT jarvis_conversation_pkey PRIMARY KEY (id);


--
-- Name: jarvis_conversation jarvis_conversation_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation
    ADD CONSTRAINT jarvis_conversation_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_conversation_summary jarvis_conversation_summary_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation_summary
    ADD CONSTRAINT jarvis_conversation_summary_pkey PRIMARY KEY (id);


--
-- Name: jarvis_conversation_summary jarvis_conversation_summary_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation_summary
    ADD CONSTRAINT jarvis_conversation_summary_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_jobs jarvis_jobs_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_jobs
    ADD CONSTRAINT jarvis_jobs_pkey PRIMARY KEY (id);


--
-- Name: jarvis_jobs jarvis_jobs_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_jobs
    ADD CONSTRAINT jarvis_jobs_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_memories jarvis_memories_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_memories
    ADD CONSTRAINT jarvis_memories_pkey PRIMARY KEY (id);


--
-- Name: jarvis_memories jarvis_memories_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_memories
    ADD CONSTRAINT jarvis_memories_rowid_key UNIQUE (rowid);


--
-- Name: jarvis_voice_sessions jarvis_voice_sessions_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_voice_sessions
    ADD CONSTRAINT jarvis_voice_sessions_pkey PRIMARY KEY (id);


--
-- Name: jarvis_voice_sessions jarvis_voice_sessions_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_voice_sessions
    ADD CONSTRAINT jarvis_voice_sessions_rowid_key UNIQUE (rowid);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: leads leads_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.leads
    ADD CONSTRAINT leads_rowid_key UNIQUE (rowid);


--
-- Name: meeting_summaries meeting_summaries_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.meeting_summaries
    ADD CONSTRAINT meeting_summaries_pkey PRIMARY KEY (id);


--
-- Name: meeting_summaries meeting_summaries_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.meeting_summaries
    ADD CONSTRAINT meeting_summaries_rowid_key UNIQUE (rowid);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.notifications
    ADD CONSTRAINT notifications_rowid_key UNIQUE (rowid);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.projects
    ADD CONSTRAINT projects_rowid_key UNIQUE (rowid);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: questions questions_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_rowid_key UNIQUE (rowid);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: resources resources_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.resources
    ADD CONSTRAINT resources_rowid_key UNIQUE (rowid);


--
-- Name: settings settings_key_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.settings
    ADD CONSTRAINT settings_key_key UNIQUE (key);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.settings
    ADD CONSTRAINT settings_rowid_key UNIQUE (rowid);


--
-- Name: sub_chats sub_chats_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.sub_chats
    ADD CONSTRAINT sub_chats_pkey PRIMARY KEY (id);


--
-- Name: sub_chats sub_chats_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.sub_chats
    ADD CONSTRAINT sub_chats_rowid_key UNIQUE (rowid);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: task_dependencies task_dependencies_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_dependencies
    ADD CONSTRAINT task_dependencies_rowid_key UNIQUE (rowid);


--
-- Name: task_dependencies task_dependencies_task_id_depends_on_task_id_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_dependencies
    ADD CONSTRAINT task_dependencies_task_id_depends_on_task_id_key UNIQUE (task_id, depends_on_task_id);


--
-- Name: task_notes task_notes_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_notes
    ADD CONSTRAINT task_notes_pkey PRIMARY KEY (id);


--
-- Name: task_notes task_notes_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_notes
    ADD CONSTRAINT task_notes_rowid_key UNIQUE (rowid);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_rowid_key UNIQUE (rowid);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_rowid_key; Type: CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.users
    ADD CONSTRAINT users_rowid_key UNIQUE (rowid);


--
-- Name: session_events session_events_pkey; Type: CONSTRAINT; Schema: viewer; Owner: -
--

ALTER TABLE ONLY viewer.session_events
    ADD CONSTRAINT session_events_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: viewer; Owner: -
--

ALTER TABLE ONLY viewer.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_hash_key; Type: CONSTRAINT; Schema: viewer; Owner: -
--

ALTER TABLE ONLY viewer.sessions
    ADD CONSTRAINT sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: calls_account; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_account ON analytics.calls USING btree (account_id NULLS FIRST, day_et NULLS FIRST);


--
-- Name: calls_agency; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_agency ON analytics.calls USING btree (agency_key NULLS FIRST, day_et NULLS FIRST);


--
-- Name: calls_day; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_day ON analytics.calls USING btree (day_et NULLS FIRST);


--
-- Name: calls_epoch; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_epoch ON analytics.calls USING btree (started_epoch NULLS FIRST);


--
-- Name: calls_local_hour; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_local_hour ON analytics.calls USING btree (hour_local NULLS FIRST);


--
-- Name: calls_session; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX calls_session ON analytics.calls USING btree (session_id NULLS FIRST);


--
-- Name: collector_runs_finished; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX collector_runs_finished ON analytics.collector_runs USING btree (finished_epoch NULLS FIRST);


--
-- Name: quotes_account; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX quotes_account ON analytics.quotes USING btree (account_id NULLS FIRST, day_et NULLS FIRST);


--
-- Name: quotes_carrier; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX quotes_carrier ON analytics.quotes USING btree (carrier NULLS FIRST, day_et NULLS FIRST);


--
-- Name: quotes_day; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX quotes_day ON analytics.quotes USING btree (day_et NULLS FIRST);


--
-- Name: revenue_bucket; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX revenue_bucket ON analytics.revenue_accounts USING btree (bucket NULLS FIRST);


--
-- Name: revenue_start; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX revenue_start ON analytics.revenue_accounts USING btree (membership_start NULLS FIRST);


--
-- Name: script_master_before_cleanup_20261015_brand_language_idx; Type: INDEX; Schema: aws_validation; Owner: -
--

CREATE INDEX script_master_before_cleanup_20261015_brand_language_idx ON aws_validation.script_master_before_cleanup_20261015 USING btree (brand NULLS FIRST, language NULLS FIRST);


--
-- Name: script_master_before_cleanup_2026101_brand_language_variant_idx; Type: INDEX; Schema: aws_validation; Owner: -
--

CREATE INDEX script_master_before_cleanup_2026101_brand_language_variant_idx ON aws_validation.script_master_before_cleanup_20261015 USING btree (brand NULLS FIRST, language NULLS FIRST, variant NULLS FIRST);


--
-- Name: script_master_before_cleanup__brand_language_variant_versio_idx; Type: INDEX; Schema: aws_validation; Owner: -
--

CREATE UNIQUE INDEX script_master_before_cleanup__brand_language_variant_versio_idx ON aws_validation.script_master_before_cleanup_20261015 USING btree (brand NULLS FIRST, language NULLS FIRST, variant NULLS FIRST, version NULLS FIRST);


--
-- Name: idx_care_events_order; Type: INDEX; Schema: gifts; Owner: -
--

CREATE INDEX idx_care_events_order ON gifts.care_events USING btree (order_id NULLS FIRST, id NULLS FIRST);


--
-- Name: idx_care_opps_agent; Type: INDEX; Schema: gifts; Owner: -
--

CREATE INDEX idx_care_opps_agent ON gifts.care_opportunities USING btree (agent_account_id NULLS FIRST, status NULLS FIRST);


--
-- Name: idx_care_orders_agent; Type: INDEX; Schema: gifts; Owner: -
--

CREATE INDEX idx_care_orders_agent ON gifts.care_orders USING btree (agent_account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_care_orders_dedup; Type: INDEX; Schema: gifts; Owner: -
--

CREATE UNIQUE INDEX idx_care_orders_dedup ON gifts.care_orders USING btree (dedup_key NULLS FIRST);


--
-- Name: idx_care_orders_status; Type: INDEX; Schema: gifts; Owner: -
--

CREATE INDEX idx_care_orders_status ON gifts.care_orders USING btree (status NULLS FIRST);


--
-- Name: idx_care_orders_token; Type: INDEX; Schema: gifts; Owner: -
--

CREATE UNIQUE INDEX idx_care_orders_token ON gifts.care_orders USING btree (fulfillment_token NULLS FIRST);


--
-- Name: idx_care_rules_agent_occasion; Type: INDEX; Schema: gifts; Owner: -
--

CREATE UNIQUE INDEX idx_care_rules_agent_occasion ON gifts.care_automation_rules USING btree (agent_account_id NULLS FIRST, occasion NULLS FIRST);


--
-- Name: idx_questions_status; Type: INDEX; Schema: help; Owner: -
--

CREATE INDEX idx_questions_status ON help.questions USING btree (status NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_applications_created; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_applications_created ON marketplace.applications USING btree (created_at NULLS FIRST);


--
-- Name: idx_applications_email; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_applications_email ON marketplace.applications USING btree (email NULLS FIRST);


--
-- Name: idx_leads_agent_slug; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_leads_agent_slug ON marketplace.leads USING btree (agent_slug NULLS FIRST);


--
-- Name: idx_leads_created_at; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_leads_created_at ON marketplace.leads USING btree (created_at NULLS FIRST);


--
-- Name: idx_privacy_requests_created; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_privacy_requests_created ON marketplace.privacy_requests USING btree (created_at NULLS FIRST);


--
-- Name: idx_privacy_requests_email; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_privacy_requests_email ON marketplace.privacy_requests USING btree (email NULLS FIRST);


--
-- Name: idx_producers_account; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_producers_account ON marketplace.producers USING btree (account_id NULLS FIRST);


--
-- Name: idx_producers_status; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_producers_status ON marketplace.producers USING btree (status NULLS FIRST);


--
-- Name: idx_producers_verified; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_producers_verified ON marketplace.producers USING btree (verified NULLS FIRST);


--
-- Name: idx_reviews_ip; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_reviews_ip ON marketplace.reviews USING btree (ip NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_reviews_slug; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_reviews_slug ON marketplace.reviews USING btree (slug NULLS FIRST, published NULLS FIRST, review_date NULLS FIRST);


--
-- Name: idx_waitlist_created; Type: INDEX; Schema: marketplace; Owner: -
--

CREATE INDEX idx_waitlist_created ON marketplace.waitlist USING btree (created_at NULLS FIRST);


--
-- Name: idx_acc_appeals_entry; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_appeals_entry ON onboarding.acc_appeals USING btree (entry_id NULLS FIRST);


--
-- Name: idx_acc_entries_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_entries_agent ON onboarding.acc_entries USING btree (agent_id NULLS FIRST);


--
-- Name: idx_acc_entries_expiry; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_entries_expiry ON onboarding.acc_entries USING btree (expires_at NULLS FIRST);


--
-- Name: idx_acc_entries_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_entries_status ON onboarding.acc_entries USING btree (status NULLS FIRST);


--
-- Name: idx_acc_events_matter; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_events_matter ON onboarding.acc_events USING btree (matter_id NULLS FIRST);


--
-- Name: idx_acc_matters_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_matters_agent ON onboarding.acc_matters USING btree (agent_id NULLS FIRST);


--
-- Name: idx_acc_matters_state; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_matters_state ON onboarding.acc_matters USING btree (state NULLS FIRST);


--
-- Name: idx_acc_notices_matter; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_notices_matter ON onboarding.acc_notices USING btree (matter_id NULLS FIRST);


--
-- Name: idx_acc_records_requests_matter; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_records_requests_matter ON onboarding.acc_records_requests USING btree (matter_id NULLS FIRST);


--
-- Name: idx_acc_review_disputes_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_acc_review_disputes_agent ON onboarding.acc_review_disputes USING btree (agent_id NULLS FIRST);


--
-- Name: idx_accounts_agency; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_accounts_agency ON onboarding.accounts USING btree (agency_id NULLS FIRST);


--
-- Name: idx_accounts_usage_payer; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_accounts_usage_payer ON onboarding.accounts USING btree (usage_payer_customer_id NULLS FIRST);


--
-- Name: idx_ack_call; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_ack_call ON onboarding.client_acknowledgments USING btree (call_id NULLS FIRST);


--
-- Name: idx_ack_client; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_ack_client ON onboarding.client_acknowledgments USING btree (client_id NULLS FIRST);


--
-- Name: idx_addl_agents_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_addl_agents_account ON onboarding.additional_agents USING btree (account_id NULLS FIRST);


--
-- Name: idx_agencies_owner; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agencies_owner ON onboarding.agencies USING btree (owner_account_id NULLS FIRST);


--
-- Name: idx_agency_team_leads_leader; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agency_team_leads_leader ON onboarding.agency_team_leads USING btree (leader_account_id NULLS FIRST);


--
-- Name: idx_agency_team_leads_member; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agency_team_leads_member ON onboarding.agency_team_leads USING btree (member_account_id NULLS FIRST);


--
-- Name: idx_agent_phone_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agent_phone_account ON onboarding.agent_phone_numbers USING btree (account_id NULLS FIRST);


--
-- Name: idx_agent_phone_e164; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_agent_phone_e164 ON onboarding.agent_phone_numbers USING btree (e164 NULLS FIRST);


--
-- Name: idx_agent_phone_numbers_non_billable; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agent_phone_numbers_non_billable ON onboarding.agent_phone_numbers USING btree (non_billable_reason NULLS FIRST);


--
-- Name: idx_agreements_active; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_agreements_active ON onboarding.agreements USING btree (is_active NULLS FIRST);


--
-- Name: idx_appsnap_client; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_appsnap_client ON onboarding.application_snapshots USING btree (client_id NULLS FIRST);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_audit_actor ON onboarding.evidence_audit_log USING btree (actor NULLS FIRST);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_audit_resource ON onboarding.evidence_audit_log USING btree (resource_type NULLS FIRST, resource_id NULLS FIRST);


--
-- Name: idx_auth_audit_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_auth_audit_account ON onboarding.auth_audit_log USING btree (account_id NULLS FIRST);


--
-- Name: idx_auth_audit_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_auth_audit_created ON onboarding.auth_audit_log USING btree (created_at NULLS FIRST);


--
-- Name: idx_auth_audit_event; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_auth_audit_event ON onboarding.auth_audit_log USING btree (event NULLS FIRST);


--
-- Name: idx_coaching_jobs_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_coaching_jobs_agent ON onboarding.coaching_jobs USING btree (agent_account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_coaching_jobs_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_coaching_jobs_status ON onboarding.coaching_jobs USING btree (status NULLS FIRST, updated_at NULLS FIRST);


--
-- Name: idx_coaching_rollups_stale; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_coaching_rollups_stale ON onboarding.coaching_rollups USING btree (stale NULLS FIRST, updated_at NULLS FIRST);


--
-- Name: idx_detections_call; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_detections_call ON onboarding.compliance_detections USING btree (call_id NULLS FIRST);


--
-- Name: idx_detections_pattern; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_detections_pattern ON onboarding.compliance_detections USING btree (pattern_id NULLS FIRST);


--
-- Name: idx_disclosure_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_disclosure_agent ON onboarding.disclosure_evidence USING btree (agent_id NULLS FIRST);


--
-- Name: idx_disclosure_call; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_disclosure_call ON onboarding.disclosure_evidence USING btree (call_id NULLS FIRST);


--
-- Name: idx_documents_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_documents_account ON onboarding.documents USING btree (account_id NULLS FIRST);


--
-- Name: idx_documents_account_live; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_documents_account_live ON onboarding.documents USING btree (account_id NULLS FIRST, deleted_at NULLS FIRST, kind NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_email_log_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_email_log_account ON onboarding.email_log USING btree (account_id NULLS FIRST);


--
-- Name: idx_email_log_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_email_log_created ON onboarding.email_log USING btree (created_at NULLS FIRST);


--
-- Name: idx_email_log_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_email_log_status ON onboarding.email_log USING btree (status NULLS FIRST);


--
-- Name: idx_envelopes_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_envelopes_agent ON onboarding.envelopes USING btree (agent_id NULLS FIRST);


--
-- Name: idx_envelopes_agree; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_envelopes_agree ON onboarding.envelopes USING btree (agreement_id NULLS FIRST);


--
-- Name: idx_envelopes_countersign; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_envelopes_countersign ON onboarding.envelopes USING btree (status NULLS FIRST, countersigned_at NULLS FIRST);


--
-- Name: idx_envelopes_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_envelopes_status ON onboarding.envelopes USING btree (status NULLS FIRST);


--
-- Name: idx_events_envelope; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_events_envelope ON onboarding.envelope_events USING btree (envelope_id NULLS FIRST);


--
-- Name: idx_events_time; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_events_time ON onboarding.envelope_events USING btree (occurred_at NULLS FIRST);


--
-- Name: idx_events_type; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_events_type ON onboarding.envelope_events USING btree (event_type NULLS FIRST);


--
-- Name: idx_headshot_finishes_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_headshot_finishes_account ON onboarding.headshot_finishes USING btree (account_id NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_headshot_finishes_token; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_headshot_finishes_token ON onboarding.headshot_finishes USING btree (token_hash NULLS FIRST);


--
-- Name: idx_headshot_jobs_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_headshot_jobs_account ON onboarding.headshot_jobs USING btree (account_id NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_headshot_jobs_state; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_headshot_jobs_state ON onboarding.headshot_jobs USING btree (state NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_headshot_spend_month; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_headshot_spend_month ON onboarding.headshot_spend USING btree (month NULLS FIRST, at DESC NULLS LAST);


--
-- Name: idx_impersonation_actions_actor; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_impersonation_actions_actor ON onboarding.impersonation_actions USING btree (actor_account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_impersonation_actions_session; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_impersonation_actions_session ON onboarding.impersonation_actions USING btree (session_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_impersonation_actions_target; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_impersonation_actions_target ON onboarding.impersonation_actions USING btree (target_account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_lead_alert_held_rings_due; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_alert_held_rings_due ON onboarding.lead_alert_held_rings USING btree (status NULLS FIRST, release_at NULLS FIRST);


--
-- Name: idx_lead_alert_probes_pending; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_alert_probes_pending ON onboarding.lead_alert_probes USING btree (status NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_lead_alert_recipients_seat; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_alert_recipients_seat ON onboarding.lead_alert_recipients USING btree (account_id NULLS FIRST, active NULLS FIRST);


--
-- Name: idx_lead_alert_recipients_seat_email; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_lead_alert_recipients_seat_email ON onboarding.lead_alert_recipients USING btree (account_id NULLS FIRST, email NULLS FIRST);


--
-- Name: idx_lead_alert_rings_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_alert_rings_account ON onboarding.lead_alert_rings USING btree (account_id NULLS FIRST, occurred_at NULLS FIRST);


--
-- Name: idx_lead_alert_rings_call; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_alert_rings_call ON onboarding.lead_alert_rings USING btree (call_control_id NULLS FIRST);


--
-- Name: idx_lead_views_lead; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_lead_views_lead ON onboarding.lead_views USING btree (lead_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_leads_created_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_leads_created_at ON onboarding.leads USING btree (created_at NULLS FIRST);


--
-- Name: idx_leads_interest_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_leads_interest_created ON onboarding.leads_interest USING btree (created_at NULLS FIRST);


--
-- Name: idx_leads_interest_crm_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_leads_interest_crm_status ON onboarding.leads_interest USING btree (crm_status NULLS FIRST);


--
-- Name: idx_license_confirm_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_license_confirm_account ON onboarding.license_confirmations USING btree (account_id NULLS FIRST);


--
-- Name: idx_license_status_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_license_status_account ON onboarding.license_status USING btree (account_id NULLS FIRST);


--
-- Name: idx_license_status_lapsed; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_license_status_lapsed ON onboarding.license_status USING btree (lapsed NULLS FIRST);


--
-- Name: idx_license_withdrawals_live; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_license_withdrawals_live ON onboarding.license_withdrawals USING btree (account_id NULLS FIRST, restored_at NULLS FIRST);


--
-- Name: idx_license_withdrawals_slug; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_license_withdrawals_slug ON onboarding.license_withdrawals USING btree (producer_slug NULLS FIRST, state NULLS FIRST, restored_at NULLS FIRST);


--
-- Name: idx_licenses_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_licenses_account ON onboarding.licenses USING btree (account_id NULLS FIRST);


--
-- Name: idx_login_events_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_login_events_account ON onboarding.login_events USING btree (account_id NULLS FIRST, at NULLS FIRST);


--
-- Name: idx_login_events_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_login_events_at ON onboarding.login_events USING btree (at NULLS FIRST);


--
-- Name: idx_number_events_account_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_events_account_at ON onboarding.number_events USING btree (account_id NULLS FIRST, at NULLS FIRST);


--
-- Name: idx_number_events_e164_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_events_e164_at ON onboarding.number_events USING btree (e164 NULLS FIRST, at NULLS FIRST);


--
-- Name: idx_number_events_kind_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_events_kind_at ON onboarding.number_events USING btree (kind NULLS FIRST, at NULLS FIRST);


--
-- Name: idx_number_releases_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_releases_status ON onboarding.number_releases USING btree (status NULLS FIRST, requested_at NULLS FIRST);


--
-- Name: idx_number_requests_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_requests_account ON onboarding.number_requests USING btree (account_id NULLS FIRST);


--
-- Name: idx_number_requests_released; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_requests_released ON onboarding.number_requests USING btree (account_id NULLS FIRST, released_at NULLS FIRST);


--
-- Name: idx_number_requests_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_number_requests_status ON onboarding.number_requests USING btree (status NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_otp_envelope; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_otp_envelope ON onboarding.envelope_otp USING btree (envelope_id NULLS FIRST);


--
-- Name: idx_password_resets_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_password_resets_account ON onboarding.password_resets USING btree (account_id NULLS FIRST);


--
-- Name: idx_password_resets_token; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_password_resets_token ON onboarding.password_resets USING btree (token_hash NULLS FIRST);


--
-- Name: idx_platform_waitlist_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_platform_waitlist_created ON onboarding.platform_waitlist USING btree (created_at NULLS FIRST);


--
-- Name: idx_pool_line_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_pool_line_account ON onboarding.pool_line_requests USING btree (account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_pool_line_one_pending; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_pool_line_one_pending ON onboarding.pool_line_requests USING btree (account_id NULLS FIRST) WHERE (status = 'pending'::text);


--
-- Name: idx_pool_line_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_pool_line_status ON onboarding.pool_line_requests USING btree (status NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_privacy_requests_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_privacy_requests_created ON onboarding.privacy_requests USING btree (created_at NULLS FIRST);


--
-- Name: idx_privacy_requests_email; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_privacy_requests_email ON onboarding.privacy_requests USING btree (email NULLS FIRST);


--
-- Name: idx_producer_documents_slug; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_producer_documents_slug ON onboarding.producer_documents USING btree (producer_slug NULLS FIRST);


--
-- Name: idx_producer_documents_state; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_producer_documents_state ON onboarding.producer_documents USING btree (producer_slug NULLS FIRST, state NULLS FIRST);


--
-- Name: idx_producer_licenses_slug; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_producer_licenses_slug ON onboarding.producer_licenses USING btree (producer_slug NULLS FIRST);


--
-- Name: idx_profiles_card_handle; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_profiles_card_handle ON onboarding.profiles USING btree (card_handle NULLS FIRST) WHERE (card_handle <> ''::text);


--
-- Name: idx_purge_agent; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_purge_agent ON onboarding.disclosure_purges USING btree (agent_id NULLS FIRST);


--
-- Name: idx_purge_call; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_purge_call ON onboarding.disclosure_purges USING btree (call_id NULLS FIRST);


--
-- Name: idx_script_brand_lang; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_script_brand_lang ON onboarding.script_master USING btree (brand NULLS FIRST, language NULLS FIRST);


--
-- Name: idx_script_brand_lang_variant; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_script_brand_lang_variant ON onboarding.script_master USING btree (brand NULLS FIRST, language NULLS FIRST, variant NULLS FIRST);


--
-- Name: idx_script_unique; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_script_unique ON onboarding.script_master USING btree (brand NULLS FIRST, language NULLS FIRST, variant NULLS FIRST, version NULLS FIRST);


--
-- Name: idx_seat_offboard_due; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_seat_offboard_due ON onboarding.seat_offboard_schedule USING btree (status NULLS FIRST, due_at NULLS FIRST);


--
-- Name: idx_seat_offboard_notices_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_seat_offboard_notices_status ON onboarding.seat_offboard_notices USING btree (notice NULLS FIRST, status NULLS FIRST);


--
-- Name: idx_seat_trial_notices_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_seat_trial_notices_status ON onboarding.seat_trial_notices USING btree (status NULLS FIRST);


--
-- Name: idx_sessions_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_sessions_account ON onboarding.sessions USING btree (account_id NULLS FIRST);


--
-- Name: idx_sessions_account_live; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_sessions_account_live ON onboarding.sessions USING btree (account_id NULLS FIRST, revoked_at NULLS FIRST);


--
-- Name: idx_sessions_impersonated; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_sessions_impersonated ON onboarding.sessions USING btree (impersonated_by NULLS FIRST, revoked_at NULLS FIRST);


--
-- Name: idx_signature_resets_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_signature_resets_account ON onboarding.agent_signature_resets USING btree (account_id NULLS FIRST);


--
-- Name: idx_signature_resets_epoch; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_signature_resets_epoch ON onboarding.agent_signature_resets USING btree (account_id NULLS FIRST, epoch NULLS FIRST);


--
-- Name: idx_signatures_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_signatures_account ON onboarding.agent_document_signatures USING btree (account_id NULLS FIRST);


--
-- Name: idx_signatures_unique; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_signatures_unique ON onboarding.agent_document_signatures USING btree (account_id NULLS FIRST, document_id NULLS FIRST, document_version NULLS FIRST, signature_epoch NULLS FIRST);


--
-- Name: idx_signdesk_routes_envelope; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_signdesk_routes_envelope ON onboarding.signdesk_routes USING btree (current_envelope_id NULLS FIRST);


--
-- Name: idx_unipile_account_id; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_unipile_account_id ON onboarding.unipile_connections USING btree (unipile_account_id NULLS FIRST);


--
-- Name: idx_usage_events_account_period; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_usage_events_account_period ON onboarding.usage_events USING btree (account_id NULLS FIRST, kind NULLS FIRST, occurred_at NULLS FIRST);


--
-- Name: idx_usage_events_billable; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_usage_events_billable ON onboarding.usage_events USING btree (occurred_at NULLS FIRST) WHERE ((reported_to_stripe_at IS NULL) AND (voided_at IS NULL));


--
-- Name: idx_usage_events_unreported; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_usage_events_unreported ON onboarding.usage_events USING btree (occurred_at NULLS FIRST) WHERE (reported_to_stripe_at IS NULL);


--
-- Name: idx_vcard_chat_usage_expires; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_vcard_chat_usage_expires ON onboarding.vcard_chat_usage USING btree (expires NULLS FIRST);


--
-- Name: idx_vcard_interest_created; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_vcard_interest_created ON onboarding.vcard_interest USING btree (created_at NULLS FIRST);


--
-- Name: idx_vsl_verif_ip; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_vsl_verif_ip ON onboarding.vsl_verification USING btree (ip NULLS FIRST, last_sent_at NULLS FIRST);


--
-- Name: idx_webrtc_cred_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_webrtc_cred_account ON onboarding.agent_webrtc_credentials USING btree (account_id NULLS FIRST);


--
-- Name: idx_webrtc_cred_sip; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_webrtc_cred_sip ON onboarding.agent_webrtc_credentials USING btree (sip_username NULLS FIRST);


--
-- Name: idx_webrtc_cred_telnyx; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX idx_webrtc_cred_telnyx ON onboarding.agent_webrtc_credentials USING btree (telnyx_credential_id NULLS FIRST);


--
-- Name: idx_welcome_sends_status; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX idx_welcome_sends_status ON onboarding.welcome_sends USING btree (status NULLS FIRST);


--
-- Name: money_events_account; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX money_events_account ON onboarding.money_events USING btree (account_id NULLS FIRST, occurred_at DESC NULLS LAST);


--
-- Name: money_events_dedupe; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE UNIQUE INDEX money_events_dedupe ON onboarding.money_events USING btree (dedupe_key NULLS FIRST);


--
-- Name: money_events_family; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX money_events_family ON onboarding.money_events USING btree (family NULLS FIRST, occurred_at DESC NULLS LAST);


--
-- Name: money_events_when; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX money_events_when ON onboarding.money_events USING btree (occurred_at DESC NULLS LAST);


--
-- Name: usage_report_runs_kind_ran_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX usage_report_runs_kind_ran_at ON onboarding.usage_report_runs USING btree (kind NULLS FIRST, ran_at NULLS FIRST);


--
-- Name: usage_report_runs_ran_at; Type: INDEX; Schema: onboarding; Owner: -
--

CREATE INDEX usage_report_runs_ran_at ON onboarding.usage_report_runs USING btree (ran_at NULLS FIRST);


--
-- Name: pbg_asset_jobs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pbg_asset_jobs_active ON public.pbg_asset_jobs USING btree (slug, draft) WHERE (status = ANY (ARRAY['queued'::text, 'running'::text]));


--
-- Name: pbg_corporate_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pbg_corporate_sessions_expiry ON public.pbg_corporate_sessions USING btree (expires_at);


--
-- Name: pbg_state_appends_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pbg_state_appends_path ON public.pbg_state_appends USING btree (path, sequence);


--
-- Name: pbg_validation_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pbg_validation_events_created ON public.pbg_validation_events USING btree (created_at);


--
-- Name: idx_actions_case; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_actions_case ON support.support_actions USING btree (case_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_actions_risk; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_actions_risk ON support.support_actions USING btree (risk NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_activation_docs; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_activation_docs ON support.support_activation_docs USING btree (activation_id NULLS FIRST);


--
-- Name: idx_activation_steps; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_activation_steps ON support.support_activation_steps USING btree (activation_id NULLS FIRST);


--
-- Name: idx_activations_operator; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_activations_operator ON support.support_activations USING btree (requested_by_operator NULLS FIRST);


--
-- Name: idx_activations_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_activations_status ON support.support_activations USING btree (status NULLS FIRST);


--
-- Name: idx_agent_meeting_items_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meeting_items_account ON support.agent_meeting_items USING btree (account_id NULLS FIRST, done NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_agent_meeting_items_meeting; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meeting_items_meeting ON support.agent_meeting_items USING btree (meeting_id NULLS FIRST, seq NULLS FIRST);


--
-- Name: idx_agent_meetings_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meetings_account ON support.agent_meetings USING btree (account_id NULLS FIRST, start_at DESC NULLS LAST);


--
-- Name: idx_agent_meetings_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meetings_status ON support.agent_meetings USING btree (status NULLS FIRST, start_at NULLS FIRST);


--
-- Name: idx_agent_meetings_uuid; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meetings_uuid ON support.agent_meetings USING btree (zoom_uuid NULLS FIRST);


--
-- Name: idx_agent_meetings_zoomid; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_agent_meetings_zoomid ON support.agent_meetings USING btree (zoom_meeting_id NULLS FIRST);


--
-- Name: idx_approvals_case; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_approvals_case ON support.support_approvals USING btree (case_id NULLS FIRST);


--
-- Name: idx_approvals_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_approvals_status ON support.support_approvals USING btree (status NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_cases_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_cases_account ON support.support_cases USING btree (account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_cases_email; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_cases_email ON support.support_cases USING btree (agent_email NULLS FIRST);


--
-- Name: idx_cases_stage; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_cases_stage ON support.support_cases USING btree (stage NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_cases_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_cases_status ON support.support_cases USING btree (status NULLS FIRST, updated_at NULLS FIRST);


--
-- Name: idx_issues_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_issues_account ON support.support_issues USING btree (account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_issues_filed_by; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_issues_filed_by ON support.support_issues USING btree (filed_by NULLS FIRST, last_change_at NULLS FIRST);


--
-- Name: idx_issues_stage; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_issues_stage ON support.support_issues USING btree (stage NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_issues_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_issues_status ON support.support_issues USING btree (status NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_jarvis_costs_at; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_jarvis_costs_at ON support.support_jarvis_costs USING btree (at NULLS FIRST);


--
-- Name: idx_jarvis_threads_seat; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_jarvis_threads_seat ON support.support_jarvis_threads USING btree (operator_id NULLS FIRST, last_at NULLS FIRST);


--
-- Name: idx_jarvis_turns_thread; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_jarvis_turns_thread ON support.support_jarvis_turns USING btree (thread_id NULLS FIRST, seq NULLS FIRST);


--
-- Name: idx_mail_case; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_mail_case ON support.support_mail_log USING btree (case_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_messages_case; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_messages_case ON support.support_messages USING btree (case_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_messages_role; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_messages_role ON support.support_messages USING btree (case_id NULLS FIRST, role NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_notes_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_notes_account ON support.support_notes USING btree (account_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_operator_events_kind; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_operator_events_kind ON support.support_operator_events USING btree (kind NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_operator_events_who; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_operator_events_who ON support.support_operator_events USING btree (operator_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_operators_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_operators_status ON support.support_operators USING btree (status NULLS FIRST, name NULLS FIRST);


--
-- Name: idx_ops_requests_approval; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_ops_requests_approval ON support.support_ops_requests USING btree (approval_id NULLS FIRST);


--
-- Name: idx_ops_requests_status; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_ops_requests_status ON support.support_ops_requests USING btree (status NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_ops_requests_subject; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_ops_requests_subject ON support.support_ops_requests USING btree (subject_account_id NULLS FIRST, created_at DESC NULLS LAST);


--
-- Name: idx_standing_marks_account; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_standing_marks_account ON support.support_standing_marks USING btree (account_id NULLS FIRST, item_key NULLS FIRST, subject NULLS FIRST, marked_at NULLS FIRST);


--
-- Name: idx_support_issues_account_via; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_support_issues_account_via ON support.support_issues USING btree (account_id NULLS FIRST, filed_via NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_support_issues_owner; Type: INDEX; Schema: support; Owner: -
--

CREATE INDEX idx_support_issues_owner ON support.support_issues USING btree (owner_operator NULLS FIRST, status NULLS FIRST);


--
-- Name: idx_approval_cases_code; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_approval_cases_code ON teamops.jarvis_approval_cases USING btree (case_code NULLS FIRST);


--
-- Name: idx_approval_cases_external; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_approval_cases_external ON teamops.jarvis_approval_cases USING btree (external_ref NULLS FIRST) WHERE ((NOT (external_ref IS NULL)) AND (deleted_at IS NULL));


--
-- Name: idx_approval_cases_pending; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_approval_cases_pending ON teamops.jarvis_approval_cases USING btree (created_at NULLS FIRST) WHERE ((status = 'pending'::text) AND (deleted_at IS NULL));


--
-- Name: idx_attachments_project; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_attachments_project ON teamops.attachments USING btree (project_id NULLS FIRST, status NULLS FIRST);


--
-- Name: idx_attachments_task; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_attachments_task ON teamops.attachments USING btree (task_id NULLS FIRST, status NULLS FIRST);


--
-- Name: idx_bookings_host_span; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_bookings_host_span ON teamops.bookings USING btree (host_id NULLS FIRST, start_utc NULLS FIRST, end_utc NULLS FIRST);


--
-- Name: idx_bookings_slot_unique; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_bookings_slot_unique ON teamops.bookings USING btree (COALESCE(host_id, 'sebastian'::text) NULLS FIRST, start_utc NULLS FIRST) WHERE ((status = 'confirmed'::text) AND (deleted_at IS NULL));


--
-- Name: idx_bookings_source_host_start; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_bookings_source_host_start ON teamops.bookings USING btree (source NULLS FIRST, host_id NULLS FIRST, start_utc NULLS FIRST) WHERE ((status = 'confirmed'::text) AND (deleted_at IS NULL));


--
-- Name: idx_bookings_source_kind_start; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_bookings_source_kind_start ON teamops.bookings USING btree (source NULLS FIRST, kind NULLS FIRST, start_utc NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_bookings_start; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_bookings_start ON teamops.bookings USING btree (start_utc NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_bookings_status_start; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_bookings_status_start ON teamops.bookings USING btree (status NULLS FIRST, start_utc NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_content_items_batch; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_items_batch ON teamops.content_items USING btree (batch_id NULLS FIRST);


--
-- Name: idx_content_items_flagged; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_items_flagged ON teamops.content_items USING btree (flagged_at NULLS FIRST) WHERE (NOT (flag_reason IS NULL));


--
-- Name: idx_content_items_queue; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_items_queue ON teamops.content_items USING btree (status NULLS FIRST, brand NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_content_items_scheduled; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_items_scheduled ON teamops.content_items USING btree (scheduled_at NULLS FIRST) WHERE (status = 'scheduled'::text);


--
-- Name: idx_content_items_uploaded_by; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_items_uploaded_by ON teamops.content_items USING btree (uploaded_by NULLS FIRST, created_at NULLS FIRST) WHERE (NOT (uploaded_by IS NULL));


--
-- Name: idx_content_posts_created; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_posts_created ON teamops.content_posts USING btree (created_at NULLS FIRST);


--
-- Name: idx_content_posts_item; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_content_posts_item ON teamops.content_posts USING btree (content_item_id NULLS FIRST);


--
-- Name: idx_founder_digest_at; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_founder_digest_at ON teamops.founder_digest USING btree (at NULLS FIRST);


--
-- Name: idx_founder_digest_unsent; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_founder_digest_unsent ON teamops.founder_digest USING btree (sent_at NULLS FIRST, at NULLS FIRST);


--
-- Name: idx_jarvis_conversation_summary_user; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_jarvis_conversation_summary_user ON teamops.jarvis_conversation_summary USING btree (user_id NULLS FIRST);


--
-- Name: idx_jarvis_conversation_user_time; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_jarvis_conversation_user_time ON teamops.jarvis_conversation USING btree (user_id NULLS FIRST, created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_jarvis_jobs_claim; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_jarvis_jobs_claim ON teamops.jarvis_jobs USING btree (status NULLS FIRST, origin NULLS FIRST, created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_jarvis_memories_project; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_jarvis_memories_project ON teamops.jarvis_memories USING btree (project_id NULLS FIRST, is_active NULLS FIRST);


--
-- Name: idx_jarvis_memories_scope; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_jarvis_memories_scope ON teamops.jarvis_memories USING btree (scope NULLS FIRST, is_active NULLS FIRST);


--
-- Name: idx_jarvis_voice_sessions_user_time; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_jarvis_voice_sessions_user_time ON teamops.jarvis_voice_sessions USING btree (user_id NULLS FIRST, created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_leads_agency_flag; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_leads_agency_flag ON teamops.leads USING btree (agency_flag NULLS FIRST) WHERE ((agency_flag = 1) AND (deleted_at IS NULL));


--
-- Name: idx_leads_booking_unique; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_leads_booking_unique ON teamops.leads USING btree (booking_id NULLS FIRST) WHERE ((NOT (booking_id IS NULL)) AND (deleted_at IS NULL));


--
-- Name: idx_leads_external_unique; Type: INDEX; Schema: teamops; Owner: -
--

CREATE UNIQUE INDEX idx_leads_external_unique ON teamops.leads USING btree (external_id NULLS FIRST) WHERE ((NOT (external_id IS NULL)) AND (deleted_at IS NULL));


--
-- Name: idx_leads_next_due; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_leads_next_due ON teamops.leads USING btree (next_action_due NULLS FIRST) WHERE ((deleted_at IS NULL) AND (NOT (next_action_due IS NULL)));


--
-- Name: idx_leads_stage; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_leads_stage ON teamops.leads USING btree (stage NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_meeting_summaries_created; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_meeting_summaries_created ON teamops.meeting_summaries USING btree (created_at NULLS FIRST);


--
-- Name: idx_meeting_summaries_lead; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_meeting_summaries_lead ON teamops.meeting_summaries USING btree (lead_id NULLS FIRST);


--
-- Name: idx_meeting_summaries_zoom_uuid; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_meeting_summaries_zoom_uuid ON teamops.meeting_summaries USING btree (zoom_uuid NULLS FIRST);


--
-- Name: idx_projects_live; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_projects_live ON teamops.projects USING btree (created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_task_notes_live; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_task_notes_live ON teamops.task_notes USING btree (task_id NULLS FIRST, created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_task_notes_task; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_task_notes_task ON teamops.task_notes USING btree (task_id NULLS FIRST, created_at NULLS FIRST);


--
-- Name: idx_tasks_live; Type: INDEX; Schema: teamops; Owner: -
--

CREATE INDEX idx_tasks_live ON teamops.tasks USING btree (created_at NULLS FIRST) WHERE (deleted_at IS NULL);


--
-- Name: idx_session_events_session; Type: INDEX; Schema: viewer; Owner: -
--

CREATE INDEX idx_session_events_session ON viewer.session_events USING btree (session_id NULLS FIRST, ts NULLS FIRST);


--
-- Name: call_coaching call_coaching_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER call_coaching_no_delete BEFORE DELETE ON onboarding.call_coaching FOR EACH ROW EXECUTE FUNCTION onboarding.call_coaching_no_delete_fn();


--
-- Name: call_coaching call_coaching_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER call_coaching_no_update BEFORE UPDATE ON onboarding.call_coaching FOR EACH ROW EXECUTE FUNCTION onboarding.call_coaching_no_update_fn();


--
-- Name: call_transcripts call_transcripts_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER call_transcripts_no_delete BEFORE DELETE ON onboarding.call_transcripts FOR EACH ROW EXECUTE FUNCTION onboarding.call_transcripts_no_delete_fn();


--
-- Name: call_transcripts call_transcripts_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER call_transcripts_no_update BEFORE UPDATE ON onboarding.call_transcripts FOR EACH ROW EXECUTE FUNCTION onboarding.call_transcripts_no_update_fn();


--
-- Name: compliance_detections compliance_detections_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER compliance_detections_no_delete BEFORE DELETE ON onboarding.compliance_detections FOR EACH ROW EXECUTE FUNCTION onboarding.compliance_detections_no_delete_fn();


--
-- Name: compliance_detections compliance_detections_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER compliance_detections_no_update BEFORE UPDATE ON onboarding.compliance_detections FOR EACH ROW EXECUTE FUNCTION onboarding.compliance_detections_no_update_fn();


--
-- Name: evidence_audit_log evidence_audit_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER evidence_audit_no_delete BEFORE DELETE ON onboarding.evidence_audit_log FOR EACH ROW EXECUTE FUNCTION onboarding.evidence_audit_no_delete_fn();


--
-- Name: evidence_audit_log evidence_audit_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER evidence_audit_no_update BEFORE UPDATE ON onboarding.evidence_audit_log FOR EACH ROW EXECUTE FUNCTION onboarding.evidence_audit_no_update_fn();


--
-- Name: script_master script_master_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER script_master_no_delete BEFORE DELETE ON onboarding.script_master FOR EACH ROW EXECUTE FUNCTION onboarding.script_master_no_delete_fn();


--
-- Name: script_master script_master_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER script_master_no_update BEFORE UPDATE ON onboarding.script_master FOR EACH ROW EXECUTE FUNCTION onboarding.script_master_no_update_fn();


--
-- Name: agent_signature_resets signature_resets_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER signature_resets_no_delete BEFORE DELETE ON onboarding.agent_signature_resets FOR EACH ROW EXECUTE FUNCTION onboarding.signature_resets_no_delete_fn();


--
-- Name: agent_signature_resets signature_resets_no_update; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER signature_resets_no_update BEFORE UPDATE ON onboarding.agent_signature_resets FOR EACH ROW EXECUTE FUNCTION onboarding.signature_resets_no_update_fn();


--
-- Name: usage_events usage_events_facts_immutable; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER usage_events_facts_immutable BEFORE UPDATE ON onboarding.usage_events FOR EACH ROW EXECUTE FUNCTION onboarding.usage_events_facts_immutable_fn();


--
-- Name: usage_events usage_events_no_delete; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER usage_events_no_delete BEFORE DELETE ON onboarding.usage_events FOR EACH ROW EXECUTE FUNCTION onboarding.usage_events_no_delete_fn();


--
-- Name: usage_events usage_events_no_void_after_report; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER usage_events_no_void_after_report BEFORE UPDATE OF voided_at ON onboarding.usage_events FOR EACH ROW EXECUTE FUNCTION onboarding.usage_events_no_void_after_report_fn();


--
-- Name: usage_events usage_events_report_stamp_once; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER usage_events_report_stamp_once BEFORE UPDATE OF reported_to_stripe_at ON onboarding.usage_events FOR EACH ROW EXECUTE FUNCTION onboarding.usage_events_report_stamp_once_fn();


--
-- Name: usage_events usage_events_void_once; Type: TRIGGER; Schema: onboarding; Owner: -
--

CREATE TRIGGER usage_events_void_once BEFORE UPDATE OF voided_at ON onboarding.usage_events FOR EACH ROW EXECUTE FUNCTION onboarding.usage_events_void_once_fn();


--
-- Name: approved_faq approved_faq_question_id_fkey; Type: FK CONSTRAINT; Schema: help; Owner: -
--

ALTER TABLE ONLY help.approved_faq
    ADD CONSTRAINT approved_faq_question_id_fkey FOREIGN KEY (question_id) REFERENCES help.questions(id);


--
-- Name: acc_appeals acc_appeals_entry_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_appeals
    ADD CONSTRAINT acc_appeals_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES onboarding.acc_entries(id);


--
-- Name: acc_appeals acc_appeals_matter_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_appeals
    ADD CONSTRAINT acc_appeals_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES onboarding.acc_matters(id);


--
-- Name: acc_entries acc_entries_matter_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_entries
    ADD CONSTRAINT acc_entries_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES onboarding.acc_matters(id);


--
-- Name: acc_notices acc_notices_matter_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_notices
    ADD CONSTRAINT acc_notices_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES onboarding.acc_matters(id);


--
-- Name: acc_records_requests acc_records_requests_matter_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.acc_records_requests
    ADD CONSTRAINT acc_records_requests_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES onboarding.acc_matters(id);


--
-- Name: accounts accounts_agency_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.accounts
    ADD CONSTRAINT accounts_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES onboarding.agencies(id);


--
-- Name: accounts accounts_lead_alert_recipient_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.accounts
    ADD CONSTRAINT accounts_lead_alert_recipient_id_fkey FOREIGN KEY (lead_alert_recipient_id) REFERENCES onboarding.lead_alert_recipients(id);


--
-- Name: additional_agents additional_agents_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.additional_agents
    ADD CONSTRAINT additional_agents_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: agencies agencies_owner_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agencies
    ADD CONSTRAINT agencies_owner_account_id_fkey FOREIGN KEY (owner_account_id) REFERENCES onboarding.accounts(id);


--
-- Name: agent_document_signatures agent_document_signatures_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_document_signatures
    ADD CONSTRAINT agent_document_signatures_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: agent_phone_numbers agent_phone_numbers_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_phone_numbers
    ADD CONSTRAINT agent_phone_numbers_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: agent_signature_resets agent_signature_resets_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_signature_resets
    ADD CONSTRAINT agent_signature_resets_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: agent_webrtc_credentials agent_webrtc_credentials_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.agent_webrtc_credentials
    ADD CONSTRAINT agent_webrtc_credentials_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: crm_presence crm_presence_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.crm_presence
    ADD CONSTRAINT crm_presence_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: documents documents_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.documents
    ADD CONSTRAINT documents_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: envelope_events envelope_events_envelope_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_events
    ADD CONSTRAINT envelope_events_envelope_id_fkey FOREIGN KEY (envelope_id) REFERENCES onboarding.envelopes(id);


--
-- Name: envelope_otp envelope_otp_envelope_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelope_otp
    ADD CONSTRAINT envelope_otp_envelope_id_fkey FOREIGN KEY (envelope_id) REFERENCES onboarding.envelopes(id);


--
-- Name: envelopes envelopes_agreement_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.envelopes
    ADD CONSTRAINT envelopes_agreement_id_fkey FOREIGN KEY (agreement_id) REFERENCES onboarding.agreements(id);


--
-- Name: lead_alert_held_rings lead_alert_held_rings_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_held_rings
    ADD CONSTRAINT lead_alert_held_rings_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: lead_alert_optins lead_alert_optins_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_optins
    ADD CONSTRAINT lead_alert_optins_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: lead_alert_probes lead_alert_probes_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_probes
    ADD CONSTRAINT lead_alert_probes_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: lead_alert_recipients lead_alert_recipients_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.lead_alert_recipients
    ADD CONSTRAINT lead_alert_recipients_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: license_confirmations license_confirmations_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_confirmations
    ADD CONSTRAINT license_confirmations_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: license_status license_status_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_status
    ADD CONSTRAINT license_status_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: license_withdrawals license_withdrawals_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.license_withdrawals
    ADD CONSTRAINT license_withdrawals_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: licenses licenses_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.licenses
    ADD CONSTRAINT licenses_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: login_events login_events_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.login_events
    ADD CONSTRAINT login_events_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: number_releases number_releases_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_releases
    ADD CONSTRAINT number_releases_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: number_requests number_requests_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.number_requests
    ADD CONSTRAINT number_requests_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: password_resets password_resets_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.password_resets
    ADD CONSTRAINT password_resets_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: producer_documents producer_documents_producer_slug_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_documents
    ADD CONSTRAINT producer_documents_producer_slug_fkey FOREIGN KEY (producer_slug) REFERENCES onboarding.vip_producers(slug);


--
-- Name: producer_licenses producer_licenses_producer_slug_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_licenses
    ADD CONSTRAINT producer_licenses_producer_slug_fkey FOREIGN KEY (producer_slug) REFERENCES onboarding.vip_producers(slug);


--
-- Name: producer_seeds producer_seeds_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.producer_seeds
    ADD CONSTRAINT producer_seeds_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: profiles profiles_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.profiles
    ADD CONSTRAINT profiles_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: seat_offboard_notices seat_offboard_notices_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_offboard_notices
    ADD CONSTRAINT seat_offboard_notices_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: seat_offboard_schedule seat_offboard_schedule_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_offboard_schedule
    ADD CONSTRAINT seat_offboard_schedule_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: seat_trial_notices seat_trial_notices_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.seat_trial_notices
    ADD CONSTRAINT seat_trial_notices_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: sessions sessions_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.sessions
    ADD CONSTRAINT sessions_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: unipile_connections unipile_connections_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.unipile_connections
    ADD CONSTRAINT unipile_connections_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: usage_events usage_events_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.usage_events
    ADD CONSTRAINT usage_events_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: welcome_sends welcome_sends_account_id_fkey; Type: FK CONSTRAINT; Schema: onboarding; Owner: -
--

ALTER TABLE ONLY onboarding.welcome_sends
    ADD CONSTRAINT welcome_sends_account_id_fkey FOREIGN KEY (account_id) REFERENCES onboarding.accounts(id);


--
-- Name: pbg_state_appends pbg_state_appends_path_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pbg_state_appends
    ADD CONSTRAINT pbg_state_appends_path_fkey FOREIGN KEY (path) REFERENCES public.pbg_state_documents(path) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attachments attachments_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES teamops.users(id);


--
-- Name: attachments attachments_note_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_note_id_fkey FOREIGN KEY (note_id) REFERENCES teamops.task_notes(id);


--
-- Name: attachments attachments_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: attachments attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES teamops.users(id);


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES teamops.users(id);


--
-- Name: bookings bookings_cancelled_by_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.bookings
    ADD CONSTRAINT bookings_cancelled_by_user_id_fkey FOREIGN KEY (cancelled_by_user_id) REFERENCES teamops.users(id);


--
-- Name: events events_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.events
    ADD CONSTRAINT events_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: events events_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.events
    ADD CONSTRAINT events_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: jarvis_conversation jarvis_conversation_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation
    ADD CONSTRAINT jarvis_conversation_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: jarvis_conversation_summary jarvis_conversation_summary_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation_summary
    ADD CONSTRAINT jarvis_conversation_summary_user_id_fkey FOREIGN KEY (user_id) REFERENCES teamops.users(id);


--
-- Name: jarvis_conversation jarvis_conversation_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_conversation
    ADD CONSTRAINT jarvis_conversation_user_id_fkey FOREIGN KEY (user_id) REFERENCES teamops.users(id);


--
-- Name: jarvis_jobs jarvis_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_jobs
    ADD CONSTRAINT jarvis_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES teamops.users(id);


--
-- Name: jarvis_memories jarvis_memories_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_memories
    ADD CONSTRAINT jarvis_memories_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES teamops.users(id);


--
-- Name: jarvis_memories jarvis_memories_created_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_memories
    ADD CONSTRAINT jarvis_memories_created_by_fkey FOREIGN KEY (created_by) REFERENCES teamops.users(id);


--
-- Name: jarvis_memories jarvis_memories_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_memories
    ADD CONSTRAINT jarvis_memories_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: jarvis_voice_sessions jarvis_voice_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.jarvis_voice_sessions
    ADD CONSTRAINT jarvis_voice_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES teamops.users(id);


--
-- Name: leads leads_booking_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.leads
    ADD CONSTRAINT leads_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES teamops.bookings(id);


--
-- Name: notifications notifications_linked_question_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.notifications
    ADD CONSTRAINT notifications_linked_question_id_fkey FOREIGN KEY (linked_question_id) REFERENCES teamops.questions(id);


--
-- Name: notifications notifications_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.notifications
    ADD CONSTRAINT notifications_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES teamops.users(id);


--
-- Name: projects projects_created_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.projects
    ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES teamops.users(id);


--
-- Name: projects projects_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.projects
    ADD CONSTRAINT projects_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES teamops.users(id);


--
-- Name: questions questions_asked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_asked_by_user_id_fkey FOREIGN KEY (asked_by_user_id) REFERENCES teamops.users(id);


--
-- Name: questions questions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES teamops.users(id);


--
-- Name: questions questions_sub_chat_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_sub_chat_id_fkey FOREIGN KEY (sub_chat_id) REFERENCES teamops.sub_chats(id);


--
-- Name: questions questions_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.questions
    ADD CONSTRAINT questions_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: resources resources_sub_chat_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.resources
    ADD CONSTRAINT resources_sub_chat_id_fkey FOREIGN KEY (sub_chat_id) REFERENCES teamops.sub_chats(id);


--
-- Name: resources resources_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.resources
    ADD CONSTRAINT resources_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: settings settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.settings
    ADD CONSTRAINT settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES teamops.users(id);


--
-- Name: sub_chats sub_chats_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.sub_chats
    ADD CONSTRAINT sub_chats_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: sub_chats sub_chats_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.sub_chats
    ADD CONSTRAINT sub_chats_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: task_dependencies task_dependencies_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_dependencies
    ADD CONSTRAINT task_dependencies_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES teamops.tasks(id);


--
-- Name: task_dependencies task_dependencies_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_dependencies
    ADD CONSTRAINT task_dependencies_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: task_notes task_notes_author_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_notes
    ADD CONSTRAINT task_notes_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES teamops.users(id);


--
-- Name: task_notes task_notes_task_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.task_notes
    ADD CONSTRAINT task_notes_task_id_fkey FOREIGN KEY (task_id) REFERENCES teamops.tasks(id);


--
-- Name: tasks tasks_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES teamops.users(id);


--
-- Name: tasks tasks_assignee_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_assignee_user_id_fkey FOREIGN KEY (assignee_user_id) REFERENCES teamops.users(id);


--
-- Name: tasks tasks_completed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_completed_by_user_id_fkey FOREIGN KEY (completed_by_user_id) REFERENCES teamops.users(id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES teamops.users(id);


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES teamops.projects(id);


--
-- Name: tasks tasks_source_event_id_fkey; Type: FK CONSTRAINT; Schema: teamops; Owner: -
--

ALTER TABLE ONLY teamops.tasks
    ADD CONSTRAINT tasks_source_event_id_fkey FOREIGN KEY (source_event_id) REFERENCES teamops.events(id);


--
-- PostgreSQL database dump complete
--

